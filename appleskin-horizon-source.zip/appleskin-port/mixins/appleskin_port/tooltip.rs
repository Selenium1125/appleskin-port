// How many lines the tooltip has, so the food row sits where vanilla puts a last line.
fn appleskin_port_tooltip(game: &crate::game::Game<'_>, lines: &[(horizon_client::text::Text, u32)]) {
    game.appleskin_tooltip_lines(lines.len());
}
