// ItemStackMixin: the food row's room under a food's tooltip.
fn appleskin_port_tooltip_component(
    game: &crate::game::Game<'_>,
    stack: &horizon_client::items::ItemStack,
    size: &mut Option<[f32; 2]>,
) {
    game.appleskin_tooltip_component(stack, size);
}
