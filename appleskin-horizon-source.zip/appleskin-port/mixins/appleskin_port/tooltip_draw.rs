// TooltipOverlayHandler.onRenderTooltip: the food row itself.
fn appleskin_port_tooltip_draw(
    game: &crate::game::Game<'_>,
    stack: &horizon_client::items::ItemStack,
    batch: &mut horizon_client::hud::HudBatch,
    origin: [f32; 2],
    size: [f32; 2],
) {
    game.appleskin_tooltip_draw(stack, batch, origin, size);
}
