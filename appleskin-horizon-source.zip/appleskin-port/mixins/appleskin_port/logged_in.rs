// PlayerListMixin: a joining player starts from nothing sent.
fn appleskin_port_logged_in(game: &mut crate::game::Game<'_>, player: u128) {
    game.appleskin_logged_in(player);
}
