// What AppleSkin reads of the game and how its draws reach the screen: the game's side of the
// port. Horizon adds this to `crate::game` as a module, so it reads the game's own state (the
// player's FoodData, the hands, the effects, the atlas) as AppleSkin's mixins read Minecraft's.

use super::Game;
use crate::game::appleskin_port as m;
use horizon_client::hud_layout::{Blend, GuiDraw, HealthInputs, PoseOp};
use horizon_client::items::ItemStack;
use std::borrow::Cow;
use std::path::PathBuf;

/// `minecraft:hud/heart/...`, `minecraft:hud/food_...`: the rows `extractHearts` and
/// `extractFood` draw, which AppleSkin's HEAD and RETURN injections sit around.
fn sprite_of(draw: &GuiDraw) -> Option<&str> {
    match draw {
        GuiDraw::Sprite { sprite, .. } => Some(sprite),
        _ => None,
    }
}

impl Game<'_> {
    fn appleskin_config_path() -> Option<PathBuf> {
        Self::native_config_dir().ok().map(|dir| dir.join(m::CONFIG_FILE))
    }

    /// `ModConfig.INSTANCE`, read from `config/appleskin.json5` the first time.
    pub(super) fn appleskin_config(&self) -> m::ModConfig {
        m::with_state(|s| m::config(s, Self::appleskin_config_path()))
    }

    /// The local player's health and food as AppleSkin reads them from `Player` and `FoodData`;
    /// `max_health` is `getMaxHealth`, as the HUD's inputs carry it.
    fn appleskin_player(&self, max_health: f32) -> Option<m::PlayerFood> {
        let p = self.player.as_ref()?;
        let effects = &self.potions.effects;
        // On another server the rule is what its AppleSkin sent (true until told otherwise, as
        // ClientSyncHandler assumes); single player's window is its own server's player.
        let natural_regeneration = if self.remote.is_some() {
            m::with_state(|s| s.client_natural_regeneration.unwrap_or(true))
        } else {
            self.world.health_rules.natural_regeneration
        };
        Some(m::PlayerFood {
            health: p.health.health(),
            max_health,
            absorption: p.health.absorption(),
            food: p.health.food.food,
            saturation: p.health.food.saturation,
            exhaustion: p.health.food.exhaustion,
            natural_regeneration,
            peaceful: self.world.health_rules.difficulty == horizon_world::food::Difficulty::Peaceful,
            hardcore: self.level.hardcore,
            poison: effects.get("poison").is_some(),
            wither: effects.get("wither").is_some(),
            regeneration: effects.get("regeneration").is_some(),
        })
    }

    /// `FoodHelper.query` of a stack's components (its item's defaults with its patch), with
    /// whether the player can eat it (`FoodHelper.canConsume`, `Player.canEat`).
    fn appleskin_query(&self, stack: &ItemStack) -> Option<m::QueriedFoodResult> {
        if stack.count == 0 || &*stack.item == "minecraft:air" {
            return None;
        }
        let view = horizon_client::item_render::stack_view(stack);
        let components = self.pack.item_renderer.models.components(&view);
        m::query(&components, |id| {
            horizon_client_core::potions::effect(id)
                .is_some_and(|e| e.category == horizon_client_core::potions::Category::Harmful)
        })
    }

    fn appleskin_hand(&self, stack: Option<&ItemStack>) -> Option<(m::QueriedFoodResult, bool)> {
        let stack = stack?;
        let food = self.appleskin_query(stack)?;
        let can = self.can_eat(stack, food.modified_food.can_always_eat);
        Some((food, can))
    }

    fn appleskin_hands(&self) -> m::Hands {
        m::Hands {
            main: self.appleskin_hand(self.inventory[self.selected].as_ref()),
            off: self.appleskin_hand(self.offhand.as_ref()),
        }
    }

    /// AppleSkin's draws as the HUD's draw calls. `icons.png` and the tooltip outline come from
    /// the atlas when the mod's assets or a resource pack put them there, else from the texels
    /// AppleSkin ships, embedded in the mod.
    fn appleskin_gui_draws(&self, draws: Vec<m::Draw>) -> Vec<GuiDraw> {
        let sprites = &self.gui.atlas.sprites;
        let icons_in_atlas = sprites.contains_key(m::MOD_ICONS);
        let outline_in_atlas = sprites.contains_key(m::HUNGER_OUTLINE_SPRITE);
        let mut out = Vec::with_capacity(draws.len());
        let rects = |out: &mut Vec<GuiDraw>, rects: Vec<(i32, i32, i32, i32, u32)>| {
            out.extend(rects.into_iter().map(|(x, y, w, h, color)| GuiDraw::Fill {
                x0: x,
                y0: y,
                x1: x + w,
                y1: y + h,
                color,
            }));
        };
        for draw in draws {
            match draw {
                m::Draw::Sprite { sprite, x, y, w, h, color } => out.push(GuiDraw::Sprite {
                    sprite: Cow::Borrowed(sprite),
                    x,
                    y,
                    w,
                    h,
                    region: None,
                    color,
                    blend: Blend::Textured,
                }),
                m::Draw::Icons { w, h, .. } if w <= 0 || h <= 0 => {}
                m::Draw::Icons { x, y, u, v, w, h, color } if icons_in_atlas => out.push(GuiDraw::Blit {
                    texture: Cow::Borrowed(m::MOD_ICONS),
                    blend: Blend::Textured,
                    x,
                    y,
                    w,
                    h,
                    uv: [u as f32, v as f32],
                    src: [w, h],
                    tex: [256, 256],
                    color,
                }),
                m::Draw::Icons { x, y, u, v, w, h, color } => {
                    rects(&mut out, m::texel_rects(m::icons_texel, x, y, u, v, w, h, color));
                }
                m::Draw::Outline { x, y, color } if outline_in_atlas => out.push(GuiDraw::Blit {
                    texture: Cow::Borrowed(m::HUNGER_OUTLINE_SPRITE),
                    blend: Blend::Textured,
                    x,
                    y,
                    w: 9,
                    h: 9,
                    uv: [0.0, 0.0],
                    src: [9, 9],
                    tex: [9, 9],
                    color,
                }),
                m::Draw::Outline { x, y, color } => {
                    rects(&mut out, m::texel_rects(m::outline_texel, x, y, 0, 0, 9, 9, color));
                }
                m::Draw::PushTranslateScale { x, y, scale } => {
                    out.push(GuiDraw::Push(vec![PoseOp::Translate(x, y), PoseOp::Scale(scale, scale)]));
                }
                m::Draw::Text { text, x, y, color } => out.push(GuiDraw::Text {
                    text: horizon_client::text::Text::literal(text),
                    x,
                    y,
                    color,
                    shadow: true,
                }),
                m::Draw::Pop => out.push(GuiDraw::Pop),
            }
        }
        out
    }

    /// `HudMixin`: the health, armour, food and air rows as Horizon lays them out, with
    /// AppleSkin's draws where its injections put them: after `extractHearts` (the health
    /// restored), at the head of `extractFood` (exhaustion, under the icons) and at its return
    /// (saturation and the food in hand).
    pub(super) fn appleskin_health_hud(
        &mut self,
        inputs: &HealthInputs,
        wi: i32,
        hi: i32,
        draws: &mut Option<Vec<GuiDraw>>,
    ) {
        if draws.is_some() || !self.native_on(m::ID) {
            return;
        }
        let Some(p) = self.appleskin_player(inputs.max_health) else {
            return;
        };
        let config = self.appleskin_config();
        let vanilla = self.native_health_hud_state().layout(inputs, wi, hi);
        let (left, right, top) = (wi / 2 - 91, wi / 2 + 91, hi - 39);
        let gui_ticks = inputs.tick;

        let is_heart = |d: &GuiDraw| sprite_of(d).is_some_and(|s| s.starts_with("hud/heart/"));
        let is_food = |d: &GuiDraw| sprite_of(d).is_some_and(|s| s.starts_with("hud/food_"));
        let food_start = vanilla.iter().position(is_food);
        let food_end = vanilla.iter().rposition(is_food).map(|i| i + 1);
        let hearts_end = vanilla
            .iter()
            .rposition(is_heart)
            .map_or_else(|| food_start.unwrap_or(vanilla.len()), |i| i + 1);

        let hands = std::cell::OnceCell::new();
        let get_hands = || hands.get_or_init(|| self.appleskin_hands()).clone();
        let health = m::with_state(|s| s.hud.render_health(&config, &p, left, top, gui_ticks, get_hands));
        let (exhaustion, food) = match food_start {
            Some(_) => m::with_state(|s| {
                let pre = s.hud.pre_render_food(&config, &p, top, right);
                let post = s.hud.render_food(&config, &p, top, right, gui_ticks, get_hands);
                (pre, post)
            }),
            None => (Vec::new(), Vec::new()),
        };

        let mut out = Vec::with_capacity(vanilla.len() + 64);
        let mut vanilla = vanilla.into_iter().enumerate().peekable();
        let mut take_until = |out: &mut Vec<GuiDraw>, end: usize| {
            while let Some((_, d)) = vanilla.next_if(|(i, _)| *i < end) {
                out.push(d);
            }
        };
        take_until(&mut out, hearts_end);
        out.extend(self.appleskin_gui_draws(health));
        if let (Some(start), Some(end)) = (food_start, food_end) {
            take_until(&mut out, start);
            out.extend(self.appleskin_gui_draws(exhaustion));
            take_until(&mut out, end);
            out.extend(self.appleskin_gui_draws(food));
        }
        take_until(&mut out, usize::MAX);
        *draws = Some(out);
    }

    /// `MinecraftMixin`: the flash steps at the head of each client tick.
    pub(super) fn appleskin_client_tick(&mut self) {
        if !self.native_on(m::ID) {
            return;
        }
        let config = self.appleskin_config();
        m::with_state(|s| s.hud.on_client_tick(&config));
    }

    /// `ItemStackMixin` + `ClientTooltipComponentMixin`: the food row under a food's tooltip, as
    /// one more component after its lines. Its size, or None when AppleSkin adds nothing.
    fn appleskin_tooltip_overlay(&self, stack: &ItemStack) -> Option<m::FoodOverlay> {
        if !self.native_on(m::ID) {
            return None;
        }
        let config = self.appleskin_config();
        let result = self.appleskin_query(stack);
        if !m::should_show_tooltip(&config, self.native_has_shift_down(), result.is_some()) {
            return None;
        }
        let overlay = m::FoodOverlay::new(&result?);
        overlay.should_render_hunger_bars().then_some(overlay)
    }

    pub(super) fn appleskin_tooltip_lines(&self, lines: usize) {
        m::with_state(|s| s.tooltip_lines = lines);
    }

    pub(super) fn appleskin_tooltip_component(&self, stack: &ItemStack, size: &mut Option<[f32; 2]>) {
        if size.is_some() {
            return;
        }
        let Some(overlay) = self.appleskin_tooltip_overlay(stack) else {
            return;
        };
        let width = overlay.width(|t| self.native_text_width(t).round() as i32);
        let lines = m::with_state(|s| s.tooltip_lines);
        let (height, _) = m::tooltip_layout(lines, overlay.height());
        *size = Some([width as f32, height as f32]);
    }

    pub(super) fn appleskin_tooltip_draw(
        &self,
        stack: &ItemStack,
        batch: &mut horizon_client::hud::HudBatch,
        origin: [f32; 2],
        size: [f32; 2],
    ) {
        let Some(overlay) = self.appleskin_tooltip_overlay(stack) else {
            return;
        };
        let lines = m::with_state(|s| s.tooltip_lines);
        let (height, dy) = m::tooltip_layout(lines, overlay.height());
        // Another mod's component, not ours.
        if (size[1] - height as f32).abs() > 0.5 {
            return;
        }
        let draws = overlay.render(origin[0].round() as i32, origin[1].round() as i32 + dy);
        let draws = self.appleskin_gui_draws(draws);
        horizon_client::hud_layout::paint(batch, &self.gui.atlas, &draws);
    }

    /// `ClientSyncHandler`: what a server's AppleSkin sends on its three channels.
    pub(super) fn appleskin_client_packet(&mut self, channel: &str, data: &[u8]) {
        match m::decode_sync(channel, data) {
            Some(m::Synced::Exhaustion(v)) => {
                if let Some(p) = self.player.as_mut() {
                    p.health.food.exhaustion = v;
                }
            }
            Some(m::Synced::Saturation(v)) => {
                if let Some(p) = self.player.as_mut() {
                    p.health.food.saturation = v;
                }
            }
            Some(m::Synced::NaturalRegeneration(v)) => {
                m::with_state(|s| s.client_natural_regeneration = Some(v));
            }
            None => {}
        }
    }

    fn appleskin_send(&mut self, player: u128, payloads: Vec<(&'static str, Vec<u8>)>) {
        for (channel, data) in payloads {
            let _ = self.native_send_custom_payload_to_player(player, channel, &data);
        }
    }

    /// `ServerPlayerMixin` (`SyncHandler.onPlayerUpdate`): at the head of each player's server
    /// tick, their saturation and exhaustion when they changed, on AppleSkin's own channels,
    /// so Java AppleSkin clients hear them too.
    pub(super) fn appleskin_player_tick(&mut self) {
        let Some(uuid) = self.lan_acting_uuid else {
            return;
        };
        let Some(p) = self.player.as_ref() else {
            return;
        };
        let (saturation, exhaustion) = (p.health.food.saturation, p.health.food.exhaustion);
        let payloads = m::with_state(|s| s.server.on_player_update(uuid, saturation, exhaustion));
        self.appleskin_send(uuid, payloads);
    }

    /// `PlayerListMixin` (`SyncHandler.onPlayerLoggedIn`).
    pub(super) fn appleskin_logged_in(&mut self, player: u128) {
        let payloads = m::with_state(|s| s.server.on_player_logged_in(player));
        self.appleskin_send(player, payloads);
    }

    /// `SyncHandler.onServerWorldTick`, at the end of each level's tick.
    pub(super) fn appleskin_level_tick(&mut self, dimension: &str) {
        let rule = self.ui.rules.bool("natural_health_regeneration");
        let Some(payload) = m::with_state(|s| s.server.on_level_tick(rule)) else {
            return;
        };
        let players: Vec<u128> = self
            .native_server_players()
            .into_iter()
            .filter(|p| p.dimension == dimension)
            .map(|p| p.uuid)
            .collect();
        for player in players {
            self.appleskin_send(player, vec![payload.clone()]);
        }
    }

    /// `DebugInfoHudEntry`: the food line in the F3 screen, in its own group.
    pub(super) fn appleskin_debug_lines(&self, d: &mut horizon_client::debug_overlay::Displayer) {
        if !self.native_on(m::ID) || !self.debug || self.reduced_debug_info() {
            return;
        }
        if !self.appleskin_config().show_food_debug_info {
            return;
        }
        let Some(p) = self.player.as_ref() else {
            return;
        };
        let food = &p.health.food;
        d.group(m::DEBUG_SECTION, [m::debug_line(food.food, food.saturation, food.exhaustion)]);
    }

    /// The mod's settings page (Options > Mods > AppleSkin): AppleSkin's config screen, a cycle
    /// button for each option, in its own words and languages.
    pub(super) fn appleskin_settings(&self, buttons: &mut Vec<String>) {
        let config = self.appleskin_config();
        let lang = horizon_client::lang::code();
        let on = horizon_client::lang::get_or("options.on", "ON");
        let off = horizon_client::lang::get_or("options.off", "OFF");
        for option in 0..m::OPTIONS.len() {
            buttons.push(m::button_label(&lang, &config, option, &on, &off));
        }
    }

    pub(super) fn appleskin_settings_click(&mut self, button: usize) {
        let path = Self::appleskin_config_path();
        m::with_state(|s| {
            let mut config = m::config(s, path.clone());
            if config.click(button) {
                m::save_config(&config, path);
                s.config = Some(config);
            }
        });
    }
}
