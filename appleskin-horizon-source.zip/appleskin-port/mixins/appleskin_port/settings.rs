// The mod's settings page: AppleSkin's config screen.
fn appleskin_port_settings(game: &mut crate::game::Game<'_>, mod_id: &str, buttons: &mut Vec<String>) {
    if mod_id == crate::game::appleskin_port::ID {
        game.appleskin_settings(buttons);
    }
}
