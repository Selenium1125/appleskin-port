// A click on the settings page: the option changes and the config file is saved.
fn appleskin_port_click(game: &mut crate::game::Game<'_>, mod_id: &str, button: usize) {
    if mod_id == crate::game::appleskin_port::ID {
        game.appleskin_settings_click(button);
    }
}
