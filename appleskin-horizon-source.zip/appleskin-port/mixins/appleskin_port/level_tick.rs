// SyncHandler.onServerWorldTick: the natural_health_regeneration rule, when it changes.
fn appleskin_port_level_tick(game: &mut crate::game::Game<'_>, dimension: &str) {
    game.appleskin_level_tick(dimension);
}
