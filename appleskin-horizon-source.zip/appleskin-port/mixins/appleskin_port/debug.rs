// DebugInfoHudEntry: hunger, saturation and exhaustion in the F3 screen.
fn appleskin_port_debug(game: &crate::game::Game<'_>, d: &mut horizon_client::debug_overlay::Displayer) {
    game.appleskin_debug_lines(d);
}
