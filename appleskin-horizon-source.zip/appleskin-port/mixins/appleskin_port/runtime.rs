// AppleSkin for Horizon: a 1:1 port of AppleSkin 3.0.10 for Minecraft 26.3 (Fabric), by squeek502,
// https://github.com/squeek502/AppleSkin (Unlicense). Ported with the author's permission.
//
// This file is AppleSkin's logic with nothing of Horizon in it: the helpers (FoodHelper,
// ColorHelper, TextureHelper), HUDOverlayHandler, TooltipOverlayHandler, the config (ModConfig),
// the sync payloads and the debug line. Horizon adds it to the game as a module; the hook helpers
// beside it feed it the game's state and paint the draws it returns. It also builds as a plain
// library so `cargo test` checks the arithmetic against the Java.

use std::collections::HashMap;
use std::sync::Mutex;

pub const ID: &str = "appleskin_port";
pub const VERSION: &str = "3.0.10";
/// AppleSkin's own config file, beside the game's `options.txt`, the same name and keys as on Java.
pub const CONFIG_FILE: &str = "appleskin.json5";

// ---------------------------------------------------------------------------------------------
// Textures (TextureHelper)
// ---------------------------------------------------------------------------------------------

/// `appleskin:textures/icons.png`, as Horizon names a mod's GUI texture in its atlas when the
/// mod's assets or a resource pack supply it.
pub const MOD_ICONS: &str = "appleskin:gui/icons";
/// `appleskin:tooltip_hunger_outline` (`textures/gui/sprites/tooltip_hunger_outline.png`).
pub const HUNGER_OUTLINE_SPRITE: &str = "appleskin:gui/sprites/tooltip_hunger_outline";

pub const FOOD_EMPTY_HUNGER_TEXTURE: &str = "hud/food_empty_hunger";
pub const FOOD_HALF_HUNGER_TEXTURE: &str = "hud/food_half_hunger";
pub const FOOD_FULL_HUNGER_TEXTURE: &str = "hud/food_full_hunger";
pub const FOOD_EMPTY_TEXTURE: &str = "hud/food_empty";
pub const FOOD_HALF_TEXTURE: &str = "hud/food_half";
pub const FOOD_FULL_TEXTURE: &str = "hud/food_full";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FoodType {
    Empty,
    Half,
    Full,
}

pub fn food_texture(is_rotten: bool, kind: FoodType) -> &'static str {
    match kind {
        FoodType::Empty if is_rotten => FOOD_EMPTY_HUNGER_TEXTURE,
        FoodType::Empty => FOOD_EMPTY_TEXTURE,
        FoodType::Half if is_rotten => FOOD_HALF_HUNGER_TEXTURE,
        FoodType::Half => FOOD_HALF_TEXTURE,
        FoodType::Full if is_rotten => FOOD_FULL_HUNGER_TEXTURE,
        FoodType::Full => FOOD_FULL_TEXTURE,
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum HeartType {
    Container,
    Full,
    Half,
}

pub fn heart_texture(hardcore: bool, kind: HeartType) -> &'static str {
    match (kind, hardcore) {
        (HeartType::Container, false) => "hud/heart/container",
        (HeartType::Container, true) => "hud/heart/container_hardcore",
        (HeartType::Full, false) => "hud/heart/full",
        (HeartType::Full, true) => "hud/heart/hardcore_full",
        (HeartType::Half, false) => "hud/heart/half",
        (HeartType::Half, true) => "hud/heart/hardcore_half",
    }
}

// ---------------------------------------------------------------------------------------------
// ColorHelper
// ---------------------------------------------------------------------------------------------

/// `ColorHelper.argbFromRGBA`: each channel `Mth.floor(c * 255.0)`.
pub fn argb_from_rgba(r: f32, g: f32, b: f32, a: f32) -> u32 {
    let ch = |c: f32| ((c as f64 * 255.0).floor() as i32) as u32;
    (ch(a) << 24) | ((ch(r) & 0xFF) << 16) | ((ch(g) & 0xFF) << 8) | (ch(b) & 0xFF)
}

/// Two ARGB colours multiplied channel by channel, as a tinted texel is drawn.
pub fn multiply(texel: u32, tint: u32) -> u32 {
    let ch = |c: u32, s: u32| (((c >> s) & 0xFF) * ((tint >> s) & 0xFF) + 127) / 255;
    (ch(texel, 24) << 24) | (ch(texel, 16) << 16) | (ch(texel, 8) << 8) | ch(texel, 0)
}

// ---------------------------------------------------------------------------------------------
// Draw calls: what AppleSkin asks GuiGraphicsExtractor for
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Debug, PartialEq)]
pub enum Draw {
    /// `blitSprite(GUI_TEXTURED, sprite, x, y, w, h, color)` of a vanilla GUI sprite.
    Sprite { sprite: &'static str, x: i32, y: i32, w: i32, h: i32, color: u32 },
    /// `blit(GUI_TEXTURED, MOD_ICONS, x, y, u, v, w, h, 256, 256, color)`.
    Icons { x: i32, y: i32, u: i32, v: i32, w: i32, h: i32, color: u32 },
    /// `blitSprite(GUI_TEXTURED, HUNGER_OUTLINE_SPRITE, x, y, 9, 9, color)`.
    Outline { x: i32, y: i32, color: u32 },
    /// `pose().pushMatrix(); translate(x, y); scale(s, s)`.
    PushTranslateScale { x: f32, y: f32, scale: f32 },
    /// `text(font, text, x, y, color)` (with its drop shadow).
    Text { text: String, x: i32, y: i32, color: u32 },
    /// `pose().popMatrix()`.
    Pop,
}

/// The texels of `icons.png` (its used corner) in ARGB, 0 where transparent or outside it.
pub fn icons_texel(u: i32, v: i32) -> u32 {
    if u < 0 || v < 0 || u as usize >= data::ICONS_W || v as usize >= data::ICONS_H {
        return 0;
    }
    match data::ICONS[v as usize].as_bytes()[u as usize] {
        b'.' => 0,
        c => data::PALETTE[usize::from(c - b'a')],
    }
}

pub fn outline_texel(u: i32, v: i32) -> u32 {
    if !(0..9).contains(&u) || !(0..9).contains(&v) {
        return 0;
    }
    if data::OUTLINE[v as usize].as_bytes()[u as usize] == b'#' { 0xFFFF_FFFF } else { 0 }
}

/// A textured blit drawn from the embedded texels when the atlas has no AppleSkin texture: one
/// rectangle per run of equal texels in a row, each the texel times the tint, 1 GUI pixel a texel
/// as `blit` draws a 256x256 texture at its own size. `(x, y, w, h, argb)`.
pub fn texel_rects(
    texel: impl Fn(i32, i32) -> u32,
    x: i32,
    y: i32,
    u: i32,
    v: i32,
    w: i32,
    h: i32,
    tint: u32,
) -> Vec<(i32, i32, i32, i32, u32)> {
    let mut out = Vec::new();
    for row in 0..h {
        let mut col = 0;
        while col < w {
            let c = texel(u + col, v + row);
            let start = col;
            while col < w && texel(u + col, v + row) == c {
                col += 1;
            }
            if c >> 24 != 0 {
                let argb = multiply(c, tint);
                if argb >> 24 != 0 {
                    out.push((x + start, y + row, col - start, 1, argb));
                }
            }
        }
    }
    out
}

// ---------------------------------------------------------------------------------------------
// java.util.Random, for the icon shake (Hud seeds it with guiTicks * 312871)
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct JavaRandom {
    seed: i64,
}

impl JavaRandom {
    const MULTIPLIER: i64 = 0x5DEECE66D;
    const MASK: i64 = (1 << 48) - 1;
    pub fn new(seed: i64) -> Self {
        Self { seed: (seed ^ Self::MULTIPLIER) & Self::MASK }
    }
    fn next(&mut self, bits: u32) -> i32 {
        self.seed = (self.seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(0xB)) & Self::MASK;
        (self.seed >> (48 - bits)) as i32
    }
    pub fn next_int(&mut self, bound: i32) -> i32 {
        let mut r = self.next(31);
        let m = bound - 1;
        if bound & m == 0 {
            return ((bound as i64 * r as i64) >> 31) as i32;
        }
        let mut u = r;
        loop {
            r = u % bound;
            if u.wrapping_sub(r).wrapping_add(m) >= 0 {
                return r;
            }
            u = self.next(31);
        }
    }
}

// ---------------------------------------------------------------------------------------------
// ModConfig
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Debug, PartialEq)]
pub struct ModConfig {
    pub show_food_values_in_tooltip: bool,
    pub show_food_values_in_tooltip_always: bool,
    pub show_saturation_hud_overlay: bool,
    pub show_food_values_hud_overlay: bool,
    pub show_food_values_hud_overlay_when_offhand: bool,
    pub show_food_exhaustion_hud_underlay: bool,
    pub show_food_health_hud_overlay: bool,
    pub show_vanilla_animations_overlay: bool,
    pub max_hud_overlay_flash_alpha: f32,
    /// AppleSkin's own older `showFoodDebugInfo` (its lang files still carry it): on Java 26.3 the
    /// line is a debug screen entry switched in F3 + F6, a list Horizon keeps to vanilla's.
    pub show_food_debug_info: bool,
}

impl Default for ModConfig {
    fn default() -> Self {
        Self {
            show_food_values_in_tooltip: true,
            show_food_values_in_tooltip_always: true,
            show_saturation_hud_overlay: true,
            show_food_values_hud_overlay: true,
            show_food_values_hud_overlay_when_offhand: true,
            show_food_exhaustion_hud_underlay: true,
            show_food_health_hud_overlay: true,
            show_vanilla_animations_overlay: true,
            max_hud_overlay_flash_alpha: 0.65,
            show_food_debug_info: true,
        }
    }
}

/// The config's keys in AppleSkin's order, with their `@Comment`s.
pub const OPTIONS: [(&str, &str); 10] = [
    ("showFoodValuesInTooltip", "If true, shows the hunger and saturation values of food in its tooltip while holding SHIFT"),
    ("showFoodValuesInTooltipAlways", "If true, shows the hunger and saturation values of food in its tooltip automatically (without needing to hold SHIFT)"),
    ("showSaturationHudOverlay", "If true, shows your current saturation level overlayed on the hunger bar"),
    ("showFoodValuesHudOverlay", "If true, shows the hunger (and saturation if showSaturationHudOverlay is true) that would be restored by food you are currently holding"),
    ("showFoodValuesHudOverlayWhenOffhand", "If true, enables the hunger/saturation/health overlays for food in your off-hand"),
    ("showFoodExhaustionHudUnderlay", "If true, shows your food exhaustion as a progress bar behind the hunger bar"),
    ("showFoodHealthHudOverlay", "If true, shows estimated health restored by food on the health bar"),
    ("showVanillaAnimationsOverlay", "If true, health/hunger overlay will shake to match Minecraft's icon animations"),
    ("maxHudOverlayFlashAlpha", "Alpha value of the flashing icons at their most visible point (1.0 = fully opaque, 0.0 = fully transparent)"),
    ("showFoodDebugInfo", "If true, shows your hunger, saturation, and exhaustion level in Debug Screen"),
];

/// The step the settings page's alpha button moves by.
pub const ALPHA_STEP: f32 = 0.05;

impl ModConfig {
    pub fn get_bool(&self, index: usize) -> Option<bool> {
        Some(match index {
            0 => self.show_food_values_in_tooltip,
            1 => self.show_food_values_in_tooltip_always,
            2 => self.show_saturation_hud_overlay,
            3 => self.show_food_values_hud_overlay,
            4 => self.show_food_values_hud_overlay_when_offhand,
            5 => self.show_food_exhaustion_hud_underlay,
            6 => self.show_food_health_hud_overlay,
            7 => self.show_vanilla_animations_overlay,
            9 => self.show_food_debug_info,
            _ => return None,
        })
    }
    fn bool_mut(&mut self, index: usize) -> Option<&mut bool> {
        Some(match index {
            0 => &mut self.show_food_values_in_tooltip,
            1 => &mut self.show_food_values_in_tooltip_always,
            2 => &mut self.show_saturation_hud_overlay,
            3 => &mut self.show_food_values_hud_overlay,
            4 => &mut self.show_food_values_hud_overlay_when_offhand,
            5 => &mut self.show_food_exhaustion_hud_underlay,
            6 => &mut self.show_food_health_hud_overlay,
            7 => &mut self.show_vanilla_animations_overlay,
            9 => &mut self.show_food_debug_info,
            _ => return None,
        })
    }
    /// A click on the settings page's button `index`: a switch flips, the alpha steps up by
    /// 0.05 and wraps from 1.0 to 0.0.
    pub fn click(&mut self, index: usize) -> bool {
        if let Some(b) = self.bool_mut(index) {
            *b = !*b;
            return true;
        }
        if index == 8 {
            let steps = (self.max_hud_overlay_flash_alpha / ALPHA_STEP).round() as i32;
            let next = if steps >= 20 { 0 } else { steps + 1 };
            self.max_hud_overlay_flash_alpha = (next as f32 * ALPHA_STEP * 100.0).round() / 100.0;
            return true;
        }
        false
    }
    /// The file Jankson writes (`toJson(true, true)`): a comment over each key.
    pub fn to_json5(&self) -> String {
        let mut out = String::from("{\n");
        for (i, (key, comment)) in OPTIONS.iter().enumerate() {
            let value = match self.get_bool(i) {
                Some(b) => b.to_string(),
                None => format_float(self.max_hud_overlay_flash_alpha),
            };
            out.push_str(&format!("\t/* {comment}\n\t*/\n\t\"{key}\": {value}"));
            out.push_str(if i + 1 < OPTIONS.len() { ",\n" } else { "\n" });
        }
        out.push_str("}\n");
        out
    }
    /// Reads the file leniently as Jankson does: comments, quoted or bare keys, trailing commas.
    /// Keys it doesn't know are ignored; keys it lacks keep their defaults.
    pub fn from_json5(text: &str) -> Self {
        let mut config = Self::default();
        let clean = strip_comments(text);
        for (key, value) in json5_pairs(&clean) {
            let Some(index) = OPTIONS.iter().position(|(k, _)| *k == key) else {
                continue;
            };
            if index == 8 {
                if let Ok(v) = value.trim_end_matches(['f', 'F']).parse::<f32>() {
                    config.max_hud_overlay_flash_alpha = v;
                }
            } else if let Some(b) = config.bool_mut(index) {
                match value.as_str() {
                    "true" => *b = true,
                    "false" => *b = false,
                    _ => {}
                }
            }
        }
        config
    }
}

fn format_float(v: f32) -> String {
    let s = format!("{v}");
    if s.contains('.') || s.contains('e') || s.contains("inf") || s.contains("NaN") { s } else { format!("{s}.0") }
}

fn strip_comments(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let b = text.as_bytes();
    let mut i = 0;
    let mut in_string = false;
    while i < b.len() {
        if in_string {
            if b[i] == b'\\' && i + 1 < b.len() {
                out.push(b[i] as char);
                out.push(b[i + 1] as char);
                i += 2;
                continue;
            }
            if b[i] == b'"' {
                in_string = false;
            }
            out.push(b[i] as char);
            i += 1;
        } else if b[i] == b'"' {
            in_string = true;
            out.push('"');
            i += 1;
        } else if b[i..].starts_with(b"/*") {
            match text[i + 2..].find("*/") {
                Some(end) => i += 2 + end + 2,
                None => break,
            }
            out.push(' ');
        } else if b[i..].starts_with(b"//") {
            while i < b.len() && b[i] != b'\n' {
                i += 1;
            }
        } else {
            out.push(b[i] as char);
            i += 1;
        }
    }
    out
}

fn json5_pairs(text: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    for part in text.split([',', '{', '}', '\n']) {
        let Some((key, value)) = part.split_once(':') else {
            continue;
        };
        let key = key.trim().trim_matches(['"', '\'']).to_owned();
        let value = value.trim().trim_matches(['"', '\'']).to_owned();
        if !key.is_empty() && !value.is_empty() {
            out.push((key, value));
        }
    }
    out
}

// ---------------------------------------------------------------------------------------------
// Translations (the config screen's strings, from AppleSkin's lang files)
// ---------------------------------------------------------------------------------------------

/// `text.autoconfig.appleskin.title`, then each option of [`OPTIONS`], then the mod's summary.
pub fn translation(lang: &str, index: usize) -> &'static str {
    let lang = lang.to_ascii_lowercase();
    let find = |code: &str| {
        data::LANGS
            .iter()
            .find(|(c, _)| *c == code)
            .and_then(|(_, values)| values.get(index).copied().flatten())
    };
    find(&lang).or_else(|| find("en_us")).unwrap_or("")
}

pub fn title(lang: &str) -> &'static str {
    translation(lang, 0)
}
pub fn option_label(lang: &str, option: usize) -> &'static str {
    translation(lang, option + 1)
}
pub fn summary(lang: &str) -> &'static str {
    translation(lang, data::LANG_KEYS - 1)
}

/// A cycle button's caption, as `options.generic_value` ("%s: %s") makes it.
pub fn button_label(lang: &str, config: &ModConfig, option: usize, on: &str, off: &str) -> String {
    let value = match config.get_bool(option) {
        Some(true) => on.to_owned(),
        Some(false) => off.to_owned(),
        None => format!("{:.2}", config.max_hud_overlay_flash_alpha),
    };
    format!("{}: {}", option_label(lang, option), value)
}

// ---------------------------------------------------------------------------------------------
// FoodHelper
// ---------------------------------------------------------------------------------------------

/// `FoodProperties`: what eating restores.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct FoodProperties {
    pub nutrition: i32,
    pub saturation: f32,
    pub can_always_eat: bool,
}

/// One `MobEffectInstance` of an `apply_effects` consume effect.
#[derive(Clone, Debug, PartialEq)]
pub struct StatusEffect {
    /// The effect's id without `minecraft:` for vanilla's (`regeneration`).
    pub id: String,
    pub amplifier: i32,
    pub duration: i32,
    pub harmful: bool,
}

/// `Consumable`: of it AppleSkin reads only its `ApplyStatusEffectsConsumeEffect`s.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Consumable {
    /// Each `apply_effects` effect's own list, in order.
    pub apply_effects: Vec<Vec<StatusEffect>>,
}

/// `FoodHelper.QueriedFoodResult`. AppleSkin's `FoodValuesEvent` lets Java mods change the values;
/// nothing does here, so the default and modified values are the stack's own.
#[derive(Clone, Debug, PartialEq)]
pub struct QueriedFoodResult {
    pub default_food: FoodProperties,
    pub modified_food: FoodProperties,
    pub consumable: Consumable,
}

pub const REGEN_EXHAUSTION_INCREMENT: f32 = 6.0;
pub const MAX_EXHAUSTION: f32 = 4.0;

/// `FoodHelper.isRotten`: any of its applied effects is harmful.
pub fn is_rotten(consumable: &Consumable) -> bool {
    consumable.apply_effects.iter().flatten().any(|e| e.harmful)
}

/// The player state `FoodHelper` and the overlays read.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PlayerFood {
    pub health: f32,
    pub max_health: f32,
    pub absorption: f32,
    pub food: i32,
    pub saturation: f32,
    pub exhaustion: f32,
    /// The `natural_health_regeneration` rule as the client knows it.
    pub natural_regeneration: bool,
    pub peaceful: bool,
    pub hardcore: bool,
    pub poison: bool,
    pub wither: bool,
    pub regeneration: bool,
}

impl PlayerFood {
    /// `LivingEntity.isHurt`.
    pub fn is_hurt(&self) -> bool {
        self.health > 0.0 && self.health < self.max_health
    }
}

/// `FoodHelper.getEstimatedHealthIncrement(Player, ConsumableFood)`.
pub fn estimated_health_increment(player: &PlayerFood, food: &FoodProperties, consumable: &Consumable) -> f32 {
    if !player.is_hurt() {
        return 0.0;
    }
    let food_level = (player.food + food.nutrition).min(20);
    let mut health_increment = 0.0f32;
    if food_level as f32 >= 18.0 && player.natural_regeneration {
        let saturation_level = (player.saturation + food.saturation).min(food_level as f32);
        health_increment = estimated_regen(food_level, saturation_level, player.exhaustion);
    }
    for effects in &consumable.apply_effects {
        if let Some(e) = effects.iter().find(|e| e.id == "regeneration") {
            let per = 50i32.wrapping_shr(e.amplifier as u32).max(1);
            health_increment += (e.duration / per) as f32;
        }
    }
    health_increment
}

/// `FoodHelper.getEstimatedHealthIncrement(int, float, float)`, float for float.
pub fn estimated_regen(mut food_level: i32, mut saturation_level: f32, mut exhaustion_level: f32) -> f32 {
    let mut health = 0.0f32;
    if !exhaustion_level.is_finite() || !saturation_level.is_finite() {
        return 0.0;
    }
    while food_level >= 18 {
        while exhaustion_level > MAX_EXHAUSTION {
            exhaustion_level -= MAX_EXHAUSTION;
            if saturation_level > 0.0 {
                saturation_level = (saturation_level - 1.0).max(0.0);
            } else {
                food_level -= 1;
            }
        }
        if food_level >= 20 && saturation_level > f32::MIN_POSITIVE {
            let limited = saturation_level.min(REGEN_EXHAUSTION_INCREMENT);
            let until_above_max = MAX_EXHAUSTION.next_up() - exhaustion_level;
            let iterations = (((until_above_max / limited) as f64).ceil() as i32).max(1);
            health += (limited / REGEN_EXHAUSTION_INCREMENT) * iterations as f32;
            exhaustion_level += limited * iterations as f32;
        } else if food_level >= 18 {
            health += 1.0;
            exhaustion_level += REGEN_EXHAUSTION_INCREMENT;
        }
    }
    health
}

// ---------------------------------------------------------------------------------------------
// HUDOverlayHandler
// ---------------------------------------------------------------------------------------------

/// `OffsetsCache`: where each heart and food icon sits this GUI tick, shake included.
#[derive(Clone, Debug, Default)]
pub struct OffsetsCache {
    pub food: Vec<(i32, i32)>,
    pub health: Vec<(i32, i32)>,
    last_gui_tick: i32,
}

impl OffsetsCache {
    pub fn generate(&mut self, gui_ticks: i32, p: &PlayerFood, animations: bool) {
        let prefer_health_bars = 10;
        let prefer_food_bars = 10;
        let absorption = (p.absorption as f64).ceil() as f32;
        let mut health_bars = (((p.max_health + absorption) / 2.0) as f64).ceil() as i32;
        if !(0..=1000).contains(&health_bars) {
            health_bars = 0;
        }
        let health_rows = ((health_bars as f32 / prefer_health_bars as f32) as f64).ceil() as i32;
        let health_row_height = (10 - (health_rows - 2)).max(3);
        let (mut animate_health, mut animate_food) = (false, false);
        if animations {
            animate_food = p.saturation <= 0.0 && gui_ticks % (p.food * 3 + 1) == 0;
            animate_health = (p.health as f64).ceil() <= 4.0;
        }
        let mut random = JavaRandom::new(gui_ticks.wrapping_mul(312871) as i64);
        self.health.resize(health_bars as usize, (0, 0));
        self.food.resize(prefer_food_bars, (0, 0));
        for i in (0..health_bars).rev() {
            let row = (((i + 1) as f32 / prefer_health_bars as f32) as f64).ceil() as i32 - 1;
            let x = i % prefer_health_bars * 8;
            let mut y = -(row * health_row_height);
            if animate_health {
                y += random.next_int(2);
            }
            self.health[i as usize] = (x, y);
        }
        for i in 0..prefer_food_bars as i32 {
            let x = -(i * 8) - 9;
            let mut y = 0;
            if animate_food {
                y += random.next_int(3) - 1;
            }
            self.food[i as usize] = (x, y);
        }
    }
    fn refresh(&mut self, gui_ticks: i32, p: &PlayerFood, animations: bool) {
        if gui_ticks != self.last_gui_tick {
            self.generate(gui_ticks, p, animations);
            self.last_gui_tick = gui_ticks;
        }
    }
}

/// `HUDOverlayHandler`'s state: the flash and the two per-tick caches.
#[derive(Debug)]
pub struct Hud {
    unclamped_flash_alpha: f32,
    flash_alpha: f32,
    alpha_dir: i8,
    pub offsets: OffsetsCache,
    held: Option<QueriedFoodResult>,
    held_last_gui_tick: i32,
}

impl Default for Hud {
    fn default() -> Self {
        Self {
            unclamped_flash_alpha: 0.0,
            flash_alpha: 0.0,
            alpha_dir: 1,
            offsets: OffsetsCache::default(),
            held: None,
            held_last_gui_tick: 0,
        }
    }
}

/// The two hands' food as `HeldFoodCache.query` tries them: each `Some` when the stack is food
/// (`FoodHelper.query`), with whether the player can eat it (`FoodHelper.canConsume`).
#[derive(Clone, Debug, Default)]
pub struct Hands {
    pub main: Option<(QueriedFoodResult, bool)>,
    pub off: Option<(QueriedFoodResult, bool)>,
}

impl Hud {
    /// `onClientTick`.
    pub fn on_client_tick(&mut self, config: &ModConfig) {
        self.unclamped_flash_alpha += self.alpha_dir as f32 * 0.125;
        if self.unclamped_flash_alpha >= 1.5 {
            self.alpha_dir = -1;
        } else if self.unclamped_flash_alpha <= -0.5 {
            self.alpha_dir = 1;
        }
        self.flash_alpha = self.unclamped_flash_alpha.clamp(0.0, 1.0) * config.max_hud_overlay_flash_alpha.clamp(0.0, 1.0);
    }
    pub fn reset_flash(&mut self) {
        self.unclamped_flash_alpha = 0.0;
        self.flash_alpha = 0.0;
        self.alpha_dir = 1;
    }
    /// `HeldFoodCache.result`: queried once per GUI tick.
    pub fn held_food(&mut self, gui_ticks: i32, config: &ModConfig, hands: impl FnOnce() -> Hands) -> Option<QueriedFoodResult> {
        if gui_ticks != self.held_last_gui_tick {
            let hands = hands();
            let mut held = hands.main;
            let can_consume = held.as_ref().is_some_and(|(_, can)| *can);
            if config.show_food_values_hud_overlay_when_offhand && !can_consume {
                held = hands.off;
            }
            self.held = held.and_then(|(food, can)| can.then_some(food));
            self.held_last_gui_tick = gui_ticks;
        }
        self.held.clone()
    }

    fn should_render_any_overlays(config: &ModConfig) -> bool {
        config.show_food_values_hud_overlay || config.show_saturation_hud_overlay || config.show_food_health_hud_overlay
    }

    /// `onPreRenderFood`: the exhaustion underlay, drawn before the food icons.
    pub fn pre_render_food(&mut self, config: &ModConfig, p: &PlayerFood, top: i32, right: i32) -> Vec<Draw> {
        let mut out = Vec::new();
        if config.show_food_exhaustion_hud_underlay {
            draw_exhaustion_overlay(&mut out, p.exhaustion, right, top);
        }
        out
    }

    /// `onRenderFood`: saturation, and the food in hand, drawn after the food icons.
    pub fn render_food(
        &mut self,
        config: &ModConfig,
        p: &PlayerFood,
        top: i32,
        right: i32,
        gui_ticks: i32,
        hands: impl FnOnce() -> Hands,
    ) -> Vec<Draw> {
        let mut out = Vec::new();
        if !Self::should_render_any_overlays(config) {
            return out;
        }
        self.offsets.refresh(gui_ticks, p, config.show_vanilla_animations_overlay);
        let saturation_shown = config.show_saturation_hud_overlay;
        if saturation_shown {
            draw_saturation_overlay(&mut out, &self.offsets.food, 0.0, p.saturation, right, top, 1.0);
        }
        let Some(result) = self.held_food(gui_ticks, config, hands) else {
            self.reset_flash();
            return out;
        };
        if config.show_food_values_hud_overlay {
            let food_hunger = result.modified_food.nutrition;
            let food_saturation_increment = result.modified_food.saturation;
            draw_hunger_overlay(
                &mut out,
                &self.offsets.food,
                food_hunger,
                p.food,
                right,
                top,
                self.flash_alpha,
                is_rotten(&result.consumable),
            );
            let new_food_value = p.food + food_hunger;
            let new_saturation_value = p.saturation + food_saturation_increment;
            if saturation_shown {
                let saturation_gained = if new_saturation_value > new_food_value as f32 {
                    new_food_value as f32 - p.saturation
                } else {
                    food_saturation_increment
                };
                draw_saturation_overlay(&mut out, &self.offsets.food, saturation_gained, p.saturation, right, top, self.flash_alpha);
            }
        }
        out
    }

    /// `onRenderHealth`: the health the food in hand would restore, drawn after the hearts.
    pub fn render_health(
        &mut self,
        config: &ModConfig,
        p: &PlayerFood,
        left: i32,
        top: i32,
        gui_ticks: i32,
        hands: impl FnOnce() -> Hands,
    ) -> Vec<Draw> {
        let mut out = Vec::new();
        if !Self::should_render_any_overlays(config) {
            return out;
        }
        let Some(result) = self.held_food(gui_ticks, config, hands) else {
            self.reset_flash();
            return out;
        };
        self.offsets.refresh(gui_ticks, p, config.show_vanilla_animations_overlay);
        if self.should_show_estimated_health(config, p) {
            let increment = estimated_health_increment(p, &result.modified_food, &result.consumable);
            let current = p.health;
            let modified = (current + increment).min(p.max_health);
            if current < modified {
                draw_health_overlay(&mut out, &self.offsets.health, current, modified, left, top, self.flash_alpha, p.hardcore);
            }
        }
        out
    }

    fn should_show_estimated_health(&self, config: &ModConfig, p: &PlayerFood) -> bool {
        config.show_food_health_hud_overlay
            && !self.offsets.health.is_empty()
            && !p.peaceful
            && p.food < 18
            && !p.poison
            && !p.wither
            && !p.regeneration
    }
}

/// `drawSaturationOverlay`.
pub fn draw_saturation_overlay(
    out: &mut Vec<Draw>,
    offsets: &[(i32, i32)],
    saturation_gained: f32,
    saturation_level: f32,
    right: i32,
    top: i32,
    alpha: f32,
) {
    if saturation_level + saturation_gained < 0.0 {
        return;
    }
    let color = argb_from_rgba(1.0, 1.0, 1.0, alpha);
    let modified = (saturation_level + saturation_gained).clamp(0.0, 20.0);
    let mut start = 0;
    let end = ((modified / 2.0) as f64).ceil() as i32;
    if saturation_gained != 0.0 {
        start = (saturation_level / 2.0).max(0.0) as i32;
    }
    let icon = 9;
    for i in start..end {
        let (ox, oy) = offsets.get(i as usize).copied().unwrap_or((0, 0));
        let effective = modified / 2.0 - i as f32;
        let u = if effective >= 1.0 {
            3 * icon
        } else if effective > 0.5 {
            2 * icon
        } else if effective > 0.25 {
            icon
        } else {
            0
        };
        out.push(Draw::Icons { x: right + ox, y: top + oy, u, v: 0, w: icon, h: icon, color });
    }
}

/// `drawHungerOverlay`.
pub fn draw_hunger_overlay(
    out: &mut Vec<Draw>,
    offsets: &[(i32, i32)],
    hunger_restored: i32,
    food_level: i32,
    right: i32,
    top: i32,
    alpha: f32,
    rotten: bool,
) {
    if hunger_restored <= 0 {
        return;
    }
    let color = argb_from_rgba(1.0, 1.0, 1.0, alpha);
    let background = argb_from_rgba(1.0, 1.0, 1.0, alpha * 0.25);
    let modified = (food_level + hunger_restored).clamp(0, 20);
    let start = (food_level / 2).max(0);
    let end = ((modified as f32 / 2.0) as f64).ceil() as i32;
    for i in start..end {
        let (ox, oy) = offsets.get(i as usize).copied().unwrap_or((0, 0));
        let (x, y) = (right + ox, top + oy);
        out.push(Draw::Sprite { sprite: food_texture(rotten, FoodType::Empty), x, y, w: 9, h: 9, color: background });
        let half = i * 2 + 1 == modified;
        let kind = if half { FoodType::Half } else { FoodType::Full };
        out.push(Draw::Sprite { sprite: food_texture(rotten, kind), x, y, w: 9, h: 9, color });
    }
}

/// `drawHealthOverlay`.
pub fn draw_health_overlay(
    out: &mut Vec<Draw>,
    offsets: &[(i32, i32)],
    health: f32,
    modified_health: f32,
    left: i32,
    top: i32,
    alpha: f32,
    hardcore: bool,
) {
    if modified_health <= health {
        return;
    }
    let color = argb_from_rgba(1.0, 1.0, 1.0, alpha);
    let background = argb_from_rgba(1.0, 1.0, 1.0, alpha * 0.25);
    let fixed_modified = (modified_health as f64).ceil() as i32;
    let start = ((health as f64).ceil() / 2.0).max(0.0) as i32;
    let end = ((modified_health / 2.0) as f64).ceil().max(0.0) as i32;
    for i in start..end {
        let (ox, oy) = offsets.get(i as usize).copied().unwrap_or((0, 0));
        let (x, y) = (left + ox, top + oy);
        out.push(Draw::Sprite { sprite: heart_texture(hardcore, HeartType::Container), x, y, w: 9, h: 9, color: background });
        let half = i * 2 + 1 == fixed_modified;
        let kind = if half { HeartType::Half } else { HeartType::Full };
        out.push(Draw::Sprite { sprite: heart_texture(hardcore, kind), x, y, w: 9, h: 9, color });
    }
}

/// `drawExhaustionOverlay`.
pub fn draw_exhaustion_overlay(out: &mut Vec<Draw>, exhaustion: f32, right: i32, top: i32) {
    let ratio = (exhaustion / MAX_EXHAUSTION).clamp(0.0, 1.0);
    let width = (ratio * 81.0) as i32;
    let color = argb_from_rgba(1.0, 1.0, 1.0, 0.75);
    out.push(Draw::Icons { x: right - width, y: top, u: 81 - width, v: 18, w: width, h: 9, color });
}

// ---------------------------------------------------------------------------------------------
// TooltipOverlayHandler
// ---------------------------------------------------------------------------------------------

/// `TooltipOverlayHandler.FoodOverlay`.
#[derive(Clone, Debug, PartialEq)]
pub struct FoodOverlay {
    pub default_food: FoodProperties,
    pub modified_food: FoodProperties,
    pub rotten: bool,
    pub hunger_bars: i32,
    pub hunger_bars_text: Option<String>,
    pub saturation_bars: i32,
    pub saturation_bars_text: Option<String>,
}

impl FoodOverlay {
    pub fn new(result: &QueriedFoodResult) -> Self {
        let biggest_hunger = result.default_food.nutrition.max(result.modified_food.nutrition);
        let biggest_saturation = result.default_food.saturation.max(result.modified_food.saturation);
        let mut hunger_bars = ((biggest_hunger.abs() as f32 / 2.0) as f64).ceil() as i32;
        let mut hunger_bars_text = None;
        if hunger_bars > 10 {
            hunger_bars_text = Some(format!("x{}", if biggest_hunger < 0 { -1 } else { 1 } * hunger_bars));
            hunger_bars = 1;
        }
        let mut saturation_bars = ((biggest_saturation.abs() / 2.0) as f64).ceil() as i32;
        let mut saturation_bars_text = None;
        if saturation_bars > 10 || saturation_bars == 0 {
            saturation_bars_text = Some(format!("x{}", if biggest_saturation < 0.0 { -1 } else { 1 } * saturation_bars));
            saturation_bars = 1;
        }
        Self {
            default_food: result.default_food,
            modified_food: result.modified_food,
            rotten: is_rotten(&result.consumable),
            hunger_bars,
            hunger_bars_text,
            saturation_bars,
            saturation_bars_text,
        }
    }
    pub fn should_render_hunger_bars(&self) -> bool {
        self.hunger_bars > 0
    }
    /// `getHeight`: hunger + spacing + saturation + arbitrary spacing.
    pub fn height(&self) -> i32 {
        9 + 1 + 7 + 3
    }
    /// `getWidth`, with the font's width of a string.
    pub fn width(&self, text_width: impl Fn(&str) -> i32) -> i32 {
        let mut hunger = self.hunger_bars * 9;
        if let Some(t) = &self.hunger_bars_text {
            hunger += text_width(t);
        }
        let mut saturation = self.saturation_bars * 7;
        if let Some(t) = &self.saturation_bars_text {
            saturation += text_width(t);
        }
        hunger.max(saturation)
    }

    /// `onRenderTooltip` at the component's top left.
    pub fn render(&self, tooltip_x: i32, tooltip_y: i32) -> Vec<Draw> {
        let mut out = Vec::new();
        let (mut x, mut y) = (tooltip_x, tooltip_y);
        let default_hunger = self.default_food.nutrition;
        let modified_hunger = self.modified_food.nutrition;
        x += (self.hunger_bars - 1) * 9;
        let mut i = 0;
        while i < self.hunger_bars * 2 {
            out.push(Draw::Sprite { sprite: FOOD_EMPTY_TEXTURE, x, y, w: 9, h: 9, color: 0xFFFF_FFFF });
            let outline = FoodOutline::get(modified_hunger, default_hunger, i);
            if outline != FoodOutline::Normal {
                out.push(Draw::Outline { x, y, color: outline.argb() });
            }
            let default_half = default_hunger - 1 == i;
            let kind = if default_half { FoodType::Half } else { FoodType::Full };
            out.push(Draw::Sprite {
                sprite: food_texture(self.rotten, kind),
                x,
                y,
                w: 9,
                h: 9,
                color: argb_from_rgba(1.0, 1.0, 1.0, 0.25),
            });
            if modified_hunger > i {
                let modified_half = modified_hunger - 1 == i;
                let kind = if modified_half { FoodType::Half } else { FoodType::Full };
                out.push(Draw::Sprite { sprite: food_texture(self.rotten, kind), x, y, w: 9, h: 9, color: 0xFFFF_FFFF });
            }
            x -= 9;
            i += 2;
        }
        if let Some(text) = &self.hunger_bars_text {
            x += 18;
            out.push(Draw::PushTranslateScale { x: x as f32, y: y as f32, scale: 0.75 });
            out.push(Draw::Text { text: text.clone(), x: 2, y: 2, color: 0xFFAA_AAAA });
            out.push(Draw::Pop);
        }

        x = tooltip_x;
        y += 10;
        let modified_saturation = self.modified_food.saturation;
        let abs_saturation = modified_saturation.abs();
        x += (self.saturation_bars - 1) * 7;
        let mut i = 0;
        while i < self.saturation_bars * 2 {
            let effective = (abs_saturation - i as f32) / 2.0;
            let faded = abs_saturation <= i as f32;
            let color = if faded { argb_from_rgba(1.0, 1.0, 1.0, 0.5) } else { argb_from_rgba(1.0, 1.0, 1.0, 1.0) };
            let u = if effective >= 1.0 {
                21
            } else if effective > 0.5 {
                14
            } else if effective > 0.25 {
                7
            } else if effective > 0.0 {
                0
            } else {
                28
            };
            let v = if modified_saturation >= 0.0 { 27 } else { 34 };
            out.push(Draw::Icons { x, y, u, v, w: 7, h: 7, color });
            x -= 7;
            i += 2;
        }
        if let Some(text) = &self.saturation_bars_text {
            x += 14;
            out.push(Draw::PushTranslateScale { x: x as f32, y: y as f32, scale: 0.75 });
            out.push(Draw::Text { text: text.clone(), x: 2, y: 1, color: 0xFFAA_AAAA });
            out.push(Draw::Pop);
        }
        out
    }
}

/// `TooltipOverlayHandler.FoodOutline`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FoodOutline {
    Negative,
    Extra,
    Normal,
    Partial,
    Missing,
}

impl FoodOutline {
    pub fn argb(self) -> u32 {
        match self {
            FoodOutline::Negative => argb_from_rgba(1.0, 1.0, 1.0, 1.0),
            FoodOutline::Extra => argb_from_rgba(0.06, 0.32, 0.02, 1.0),
            FoodOutline::Normal => argb_from_rgba(0.0, 0.0, 0.0, 1.0),
            FoodOutline::Partial => argb_from_rgba(0.53, 0.21, 0.08, 1.0),
            FoodOutline::Missing => argb_from_rgba(0.62, 0.0, 0.0, 0.5),
        }
    }
    pub fn get(modified: i32, default: i32, i: i32) -> Self {
        if modified < 0 {
            FoodOutline::Negative
        } else if modified > default && default <= i {
            FoodOutline::Extra
        } else if modified > i + 1 || default == modified {
            FoodOutline::Normal
        } else if modified == i + 1 {
            FoodOutline::Partial
        } else {
            FoodOutline::Missing
        }
    }
}

/// `shouldShowTooltip`, past the empty stack and hidden tooltip checks Horizon makes itself.
pub fn should_show_tooltip(config: &ModConfig, shift_down: bool, is_food: bool) -> bool {
    ((config.show_food_values_in_tooltip && shift_down) || config.show_food_values_in_tooltip_always) && is_food
}

/// The component's size and offset in Horizon's tooltip box, so the box comes out as vanilla's:
/// vanilla lays a lone name line out 8 high and every other line 10, with 2 more under the
/// first, and AppleSkin's food row is one more line (`getHeight` 20). Horizon reserves its
/// component's height plus 2 after the text. `(reserved height, y offset to draw at)`.
pub fn tooltip_layout(text_lines: usize, height: i32) -> (i32, i32) {
    if text_lines <= 1 { (height, 2) } else { (height - 2, 0) }
}

// ---------------------------------------------------------------------------------------------
// Sync (SyncHandler, ClientSyncHandler and their payloads)
// ---------------------------------------------------------------------------------------------

pub const CHANNEL_EXHAUSTION: &str = "appleskin:exhaustion";
pub const CHANNEL_SATURATION: &str = "appleskin:saturation";
pub const CHANNEL_NATURAL_REGENERATION: &str = "appleskin:natural_regeneration";

/// `buf.writeFloat`.
pub fn encode_float(v: f32) -> [u8; 4] {
    v.to_bits().to_be_bytes()
}
/// `buf.readFloat`.
pub fn decode_float(data: &[u8]) -> Option<f32> {
    Some(f32::from_bits(u32::from_be_bytes(data.get(..4)?.try_into().ok()?)))
}
/// `buf.writeBoolean`.
pub fn encode_bool(v: bool) -> [u8; 1] {
    [u8::from(v)]
}
/// `buf.readBoolean`.
pub fn decode_bool(data: &[u8]) -> Option<bool> {
    data.first().map(|b| *b != 0)
}

/// What a client heard from its server (`ClientSyncHandler`).
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Synced {
    Exhaustion(f32),
    Saturation(f32),
    NaturalRegeneration(bool),
}

pub fn decode_sync(channel: &str, data: &[u8]) -> Option<Synced> {
    match channel {
        CHANNEL_EXHAUSTION => decode_float(data).map(Synced::Exhaustion),
        CHANNEL_SATURATION => decode_float(data).map(Synced::Saturation),
        CHANNEL_NATURAL_REGENERATION => decode_bool(data).map(Synced::NaturalRegeneration),
        _ => None,
    }
}

/// `SyncHandler`'s state on a server.
#[derive(Debug)]
pub struct ServerSync {
    last_saturation: HashMap<u128, f32>,
    last_exhaustion: HashMap<u128, f32>,
    natural_regeneration: bool,
}

impl Default for ServerSync {
    fn default() -> Self {
        Self { last_saturation: HashMap::new(), last_exhaustion: HashMap::new(), natural_regeneration: true }
    }
}

impl ServerSync {
    /// `onPlayerUpdate`: the payloads to send this player.
    pub fn on_player_update(&mut self, player: u128, saturation: f32, exhaustion: f32) -> Vec<(&'static str, Vec<u8>)> {
        let mut out = Vec::new();
        let last_saturation = self.last_saturation.get(&player).copied();
        if last_saturation != Some(saturation) {
            out.push((CHANNEL_SATURATION, encode_float(saturation).to_vec()));
            self.last_saturation.insert(player, saturation);
        }
        let last_exhaustion = self.last_exhaustion.get(&player).copied();
        if last_exhaustion.is_none_or(|last| (last - exhaustion).abs() >= 0.01) {
            out.push((CHANNEL_EXHAUSTION, encode_float(exhaustion).to_vec()));
            self.last_exhaustion.insert(player, exhaustion);
        }
        out
    }
    /// `onPlayerLoggedIn`.
    pub fn on_player_logged_in(&mut self, player: u128) -> Vec<(&'static str, Vec<u8>)> {
        self.last_saturation.remove(&player);
        self.last_exhaustion.remove(&player);
        if self.natural_regeneration {
            Vec::new()
        } else {
            vec![(CHANNEL_NATURAL_REGENERATION, encode_bool(false).to_vec())]
        }
    }
    /// `onServerWorldTick`: Some(payload) for the level's players when the rule changed.
    pub fn on_level_tick(&mut self, natural_regeneration: bool) -> Option<(&'static str, Vec<u8>)> {
        if self.natural_regeneration != natural_regeneration {
            self.natural_regeneration = natural_regeneration;
            return Some((CHANNEL_NATURAL_REGENERATION, encode_bool(natural_regeneration).to_vec()));
        }
        None
    }
}

// ---------------------------------------------------------------------------------------------
// DebugInfoHudEntry
// ---------------------------------------------------------------------------------------------

pub const DEBUG_SECTION: &str = "appleskin:debug_info";

/// `java.text.DecimalFormat` with at most `max` and at least `min` fraction digits, rounding
/// HALF_EVEN on the float's exact value, as it formats a float widened to a double.
pub fn decimal_format(v: f32, min: usize, max: usize) -> String {
    let v = v as f64;
    if !v.is_finite() {
        return if v.is_nan() { "NaN".into() } else if v > 0.0 { "∞".into() } else { "-∞".into() };
    }
    let exact = format!("{:.60}", v.abs());
    let (int_part, frac_part) = exact.split_once('.').unwrap_or((&exact, ""));
    let mut digits: Vec<u8> = int_part.bytes().chain(frac_part.bytes()).map(|b| b - b'0').collect();
    let int_len = int_part.len();
    let keep = int_len + max;
    let rest = &digits[keep..];
    let round_up = match rest.first() {
        Some(&d) if d > 5 => true,
        Some(&5) => rest[1..].iter().any(|&d| d != 0) || (keep > 0 && digits[keep - 1] % 2 == 1),
        _ => false,
    };
    digits.truncate(keep);
    let mut int_len = int_len;
    if round_up {
        let mut i = digits.len();
        loop {
            if i == 0 {
                digits.insert(0, 1);
                int_len += 1;
                break;
            }
            i -= 1;
            if digits[i] == 9 {
                digits[i] = 0;
            } else {
                digits[i] += 1;
                break;
            }
        }
    }
    let mut int_s: String = digits[..int_len].iter().map(|d| (b'0' + d) as char).collect();
    let int_trimmed = int_s.trim_start_matches('0');
    int_s = if int_trimmed.is_empty() { "0".into() } else { int_trimmed.into() };
    let mut frac: String = digits[int_len..].iter().map(|d| (b'0' + d) as char).collect();
    while frac.len() > min && frac.ends_with('0') {
        frac.pop();
    }
    let negative = v < 0.0 && (int_s != "0" || frac.bytes().any(|b| b != b'0'));
    let mut out = String::new();
    if negative {
        out.push('-');
    }
    out.push_str(&int_s);
    if !frac.is_empty() {
        out.push('.');
        out.push_str(&frac);
    }
    out
}

/// `DebugInfoHudEntry.display`'s line.
pub fn debug_line(food: i32, saturation: f32, exhaustion: f32) -> String {
    format!(
        "hunger: {}, sat: {}, exh: {}/{}",
        food,
        decimal_format(saturation, 0, 2),
        decimal_format(exhaustion, 2, 2),
        decimal_format(MAX_EXHAUSTION, 0, 2),
    )
}

// ---------------------------------------------------------------------------------------------
// The mod's state in the game
// ---------------------------------------------------------------------------------------------

#[derive(Debug, Default)]
pub struct State {
    /// None until the config file is first read.
    pub config: Option<ModConfig>,
    pub hud: Hud,
    pub server: ServerSync,
    /// `ClientSyncHandler.naturalRegeneration`, as a server sent it.
    pub client_natural_regeneration: Option<bool>,
    /// The text lines of the tooltip being built, for [`tooltip_layout`].
    pub tooltip_lines: usize,
}

pub static STATE: Mutex<Option<State>> = Mutex::new(None);

/// Runs `f` on the mod's state.
pub fn with_state<R>(f: impl FnOnce(&mut State) -> R) -> R {
    let mut guard = STATE.lock().unwrap_or_else(|e| e.into_inner());
    f(guard.get_or_insert_with(State::default))
}

/// The config, read from `path` the first time (and written there when the file is missing, as
/// `ModConfig.load` does).
pub fn config(state: &mut State, path: Option<std::path::PathBuf>) -> ModConfig {
    if let Some(c) = &state.config {
        return c.clone();
    }
    let config = match path.as_ref().map(std::fs::read_to_string) {
        Some(Ok(text)) => ModConfig::from_json5(&text),
        _ => {
            let c = ModConfig::default();
            if let Some(path) = &path {
                let _ = std::fs::write(path, c.to_json5());
            }
            c
        }
    };
    state.config = Some(config.clone());
    config
}

/// `ModConfig.save`.
pub fn save_config(config: &ModConfig, path: Option<std::path::PathBuf>) {
    if let Some(path) = path {
        let _ = std::fs::write(path, config.to_json5());
    }
}

/// The JSON value of a stack's component, read into AppleSkin's types: `minecraft:food`.
pub fn parse_food(food: &serde_json::Value) -> FoodProperties {
    FoodProperties {
        nutrition: food.get("nutrition").and_then(serde_json::Value::as_i64).unwrap_or(0) as i32,
        saturation: food.get("saturation").and_then(serde_json::Value::as_f64).unwrap_or(0.0) as f32,
        can_always_eat: food.get("can_always_eat").and_then(serde_json::Value::as_bool).unwrap_or(false),
    }
}

/// `minecraft:consumable`'s `apply_effects` consume effects; `harmful` names an effect's category.
pub fn parse_consumable(consumable: &serde_json::Value, harmful: impl Fn(&str) -> bool) -> Consumable {
    let mut out = Consumable::default();
    let Some(effects) = consumable.get("on_consume_effects").and_then(serde_json::Value::as_array) else {
        return out;
    };
    for effect in effects {
        let kind = effect.get("type").and_then(serde_json::Value::as_str).unwrap_or("");
        if kind.trim_start_matches("minecraft:") != "apply_effects" {
            continue;
        }
        let list = effect.get("effects").and_then(serde_json::Value::as_array).cloned().unwrap_or_default();
        out.apply_effects.push(
            list.iter()
                .filter_map(|e| {
                    let id = e.get("id").and_then(serde_json::Value::as_str)?;
                    let short = id.strip_prefix("minecraft:").unwrap_or(id).to_owned();
                    Some(StatusEffect {
                        harmful: harmful(id),
                        id: short,
                        amplifier: e.get("amplifier").and_then(serde_json::Value::as_i64).unwrap_or(0) as i32,
                        duration: e.get("duration").and_then(serde_json::Value::as_i64).unwrap_or(0) as i32,
                    })
                })
                .collect(),
        );
    }
    out
}

/// `FoodHelper.query` on a stack's merged components: None unless it has both `minecraft:food`
/// and `minecraft:consumable` (`isFood`).
pub fn query(
    components: &std::collections::BTreeMap<String, serde_json::Value>,
    harmful: impl Fn(&str) -> bool,
) -> Option<QueriedFoodResult> {
    let food = components.get("minecraft:food")?;
    let consumable = components.get("minecraft:consumable")?;
    let food = parse_food(food);
    Some(QueriedFoodResult { default_food: food, modified_food: food, consumable: parse_consumable(consumable, harmful) })
}

// The embedded data: AppleSkin's textures and lang strings.
pub mod data {
    // Generated from AppleSkin 3.0.10+mc26.3 (squeek502, Unlicense): textures/icons.png
    // (its used 81x41 corner, one letter per palette colour, "." transparent), the tooltip
    // outline sprite, and the config screen strings of every lang file it ships.
    pub const ICONS_W: usize = 81;
    pub const ICONS_H: usize = 41;
    pub const PALETTE: [u32; 10] = [0xFFE9D262, 0xFFDDC241, 0xFFC2A100, 0xFF9F8609, 0xFFFB1900, 0xFFE01700, 0xFFAB1200, 0xFF9B1100, 0xFF282828, 0xFF0A0A0A];
    pub const ICONS: [&str; 41] = [
        "............a.......aa.......aa..................................................",
        ".............b........b.....b..b.................................................",
        "..............c........c...c....c................................................",
        "...............c........c..c.....c...............................................",
        "......c........c........c...d....c...............................................",
        "......c........c....d...c....d...c...............................................",
        ".....d.cc....dd.cc...ddd.cc...ddd.cc.............................................",
        "......d.c......d.c......d.c......d.c.............................................",
        "......dd.......dd.......dd.......dd..............................................",
        "............e.......ee.......ee..................................................",
        ".............f........f.....f..f.................................................",
        "..............g........g...g....g................................................",
        "...............g........g..g.....g...............................................",
        "......g........g........g...h....g...............................................",
        "......g........g....h...g....h...g...............................................",
        ".....h.gg....hh.gg...hhh.gg...hhh.gg.............................................",
        "......h.g......h.g......h.g......h.g.............................................",
        "......hh.......hh.......hh.......hh..............................................",
        ".i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.",
        "i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i",
        ".i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.",
        "i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i",
        ".i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.",
        "i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i",
        ".i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.",
        "i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i",
        ".i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.i.",
        "..j......j......j......b......j..................................................",
        ".jij....jij....jib....bib....jij.................................................",
        "jiiij..jiiic..jiiic..ciiic..jiiij................................................",
        ".jiic...jiic...jiic...diic...jiij................................................",
        "..jjicc..jdicc..ddicc..ddicc..jjijj..............................................",
        "....dic....dic....dic....dic....jij..............................................",
        "....dd.....dd.....dd.....dd.....jj...............................................",
        "..j......j......j......f......j..................................................",
        ".jij....jij....jif....fif....jij.................................................",
        "jiiij..jiiig..jiiig..hiiig..jiiij................................................",
        ".jiig...jiig...jiig...hiig...jiij................................................",
        "..jjigg..jgigg..ggigg..hhigg..jjijj..............................................",
        "....gig....gig....gig....hig....jij..............................................",
        "....gg.....gg.....gg.....hh.....jj...............................................",
    ];
    pub const OUTLINE: [&str; 9] = [
        "..##.....",
        ".#..#....",
        "#....#...",
        "#.....#..",
        ".#....#..",
        "..#...#..",
        "...###.##",
        "......#.#",
        "......##.",
    ];
    pub const LANG_KEYS: usize = 12;
    pub const LANGS: [(&str, [Option<&str>; LANG_KEYS]); 22] = [
        ("cs_cz", [Some("AppleSkin"), Some("Zobrazit hodnoty jídla v nápovědě"), Some("Vždy zobrazovat hodnoty jídla v nápovědě"), Some("Zobrazit překrytí sytosti"), Some("Zobrazit obnovení hladu z drženého jídla"), Some("Zobrazeit překryvy pro jídlo v režimu mimo dosah ruky"), Some("Zobrazit odkrytí hladu"), Some("Zobrazit překrytí odhadovaného stavu"), Some("Animovat ikony hladu (HUD) tak, aby odpovídaly Minecraftu"), Some("Neprůhlednost blikajících ikon hladu (HUD)"), Some("Zobrazit hodnoty jídla na obrazovce ladění"), Some("Přidá různá vylepšení HUD související s jídlem")]),
        ("de_de", [Some("AppleSkin"), Some("Zeige Sättigungswerte im Tooltip an"), Some("Zeige Sättigungswerte immer im Tooltip an"), Some("Zeige Sättigungs-Overlay"), Some("Zeige Hungerregeneration durch in der hand gehaltenes Essen"), Some("Zeige Overlays für in Offhand gehaltenes Essen"), Some("Zeige Erschöpfungs-Unterlage"), Some("Zeige geschätzte Gesundheits regeneration im Overlay"), Some("Animiere HUD Icons passend zu Minecraft"), Some("Max Alpha von aufleuchtenden HUD icons"), Some("Zeige Essens-werte im Debug Bildschirm"), Some("Fügt verschiedene HUD-Verbesserungen im Zusammenhang mit Essen hinzu")]),
        ("en_us", [Some("AppleSkin"), Some("Show food values in tooltip"), Some("Always show food values in tooltip"), Some("Show saturation overlay"), Some("Show hunger restored from held food"), Some("Show overlays for food in off-hand"), Some("Show exhaustion underlay"), Some("Show estimated health overlay"), Some("Animate HUD icons to match Minecraft"), Some("Max alpha of flashing HUD icons"), Some("Show food values in Debug Screen"), Some("Adds various food-related HUD improvements")]),
        ("es_ar", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("es_cl", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("es_ec", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("es_es", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("es_mx", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("es_uy", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("es_ve", [Some("AppleSkin"), Some("Valores de comida en la descripción emergente"), Some("Valores de comida en la descripción emergente, siempre"), Some("Barra de saturación"), Some("Hambre por restaurar de la comida que tienes en la mano"), Some("Hambre por restaurar de la comida que tienes en la mano secundaria"), Some("Barra de agotamiento"), Some("Salud que se restaurará por la comida que tienes en la mano"), Some("Animar los íconos del HUD para que coincidan con Minecraft"), Some("Transparencia máxima de los íconos parpadeantes"), Some("Valores de la comida en la pantalla de depuración"), Some("Agrega varias mejoras relacionadas con los alimentos en el HUD")]),
        ("fr_fr", [Some("AppleSkin"), Some("Montrer la nourriture dans les info-bulles"), Some("Toujours montrer la nourriture dans les info-bulles"), Some("Montrer la saturation"), Some("Montrer la faim restaurée par la nourriture tenue en main"), Some("Montrer la faim restaurée par la nourriture tenue dans la main secondaire"), Some("Montrer l'épuisement"), Some("Montrer l'estimation de vie restaurée"), Some("Animer les icônes sur l'ATH"), Some("Opacité des icônes clignotantes de l'ATH"), Some("Montrer la nourriture sur l'écran de déboguage"), Some("Ajoute diverses améliorations de l'ATH liées à la nourriture")]),
        ("hy_am", [Some("AppleSkin"), Some("Ցույց տալ սննդի արժեքները հուշումում"), Some("Միշտ ցույց տալ սննդի արժեքները հուշումում"), Some("Ցույց տալ հագեցվախության ծածկույթը"), Some("Ցույց տալ պահված սննդից վերականգնված քաղցը"), Some("Ցույց տալ սննդի ծածկույթը ձեռքից դուրս"), Some("Ցույց տալ սովի գիծը"), Some("Ցույց տալ գնահատված առողջության ծածկույթը"), Some("Անիմացրեք HUD պատկերակները՝ Minecraft-ին համապատասխանելու համար"), Some("Մաքսկիմալ անթափանցիկություն ծածկույթի թարթման ժամանակ"), Some("Ցուցադրել սննդի արժեքները վրիպազերծման էկրանում"), Some("Ավելացնում է սննդի հետ կապված տարբեր HUD բարելավումներ")]),
        ("ja_jp", [Some("AppleSkin"), Some("ツールチップに食料値を表示"), Some("常に食料値をツールチップに表示"), Some("満腹度オーバーレイを表示"), Some("所持している食料の回復量を表示"), Some("オフハンドの食料にもオーバーレイを表示"), Some("疲労度のアンダーレイ表示"), Some("予測される体力回復を表示"), Some("HUDアイコンをバニラのアニメーションに合わせて動かす"), Some("HUDアイコンの最大フラッシュ透明度"), Some("デバッグ画面に食料値を表示"), Some("食料関連のHUDを改善するMOD")]),
        ("ko_kr", [Some("AppleSkin"), Some("아이템 설명에 회복량 표시"), Some("아이템 설명에 회복량 항상 표시"), Some("포만감을 오버레이에 표시"), Some("들고 있는 아이템의 회복량을 오버레이에 표시"), Some("다른 손에 든 아이템의 회복량을 오버레이에 표시"), Some("소진량을 언더레이에 표시"), Some("체력 회복량을 오버레이 표시"), Some("허기 HUD에 애니메이션 적용"), Some("발광 HUD의 최대 투명도 값"), Some("디버그 화면에 회복량 표시"), Some("음식과 관련된 HUD에 다양한 개선 사항을 추가합니다.")]),
        ("pl_pl", [Some("AppleSkin"), Some("Pokazuj wartości jedzenia w podpowiedziach"), Some("Zawsze pokazuj wartości jedzenia w podpowiedziach"), Some("Pokazuj nakładkę nasycenia"), Some("Pokazuj głód przywracany z trzymanego jedzenia"), Some("Pokazuj nakładki dla jedzenia w ręce pobocznej"), Some("Pokazuj nakładkę zmęczenia"), Some("Pokazuj nakładkę szacowanego zdrowia"), Some("Animuj ikony inwentarza, aby pasowały do Minecrafta"), Some("Maksymalna przezroczystość blyszczących ikon inwentarza"), Some("Pokazuj wartości jedzenia w ekranie debugowania"), Some("Dodaje różne ulepszenia interfejsu związane z jedzeniem")]),
        ("pt_br", [Some("AppleSkin"), Some("Mostrar valores de comida na dica de ferramenta"), Some("Sempre mostrar valores de comida na dica de ferramenta"), Some("Mostrar sobreposição de saturação"), Some("Mostrar fome restaurada pela comida segurada"), Some("Mostrar sobreposições para comida na mão secundária"), Some("Mostrar subcamada de exaustão"), Some("Mostrar sobreposição de vida estimada"), Some("Animar ícones do HUD como no Minecraft"), Some("Alfa máximo dos ícones do HUD piscantes"), Some("Mostrar valores de comida na tela de depuração"), Some("Adiciona várias melhorias no HUD relacionadas a comida")]),
        ("ru_ru", [Some("Настройки AppleSkin"), Some("Характеристики еды в подсказке к ней"), Some("Отображать характеристики постоянно"), Some("Отображение и оценка насыщения"), Some("Оценка утоления голода едой"), Some("Учитывать предметы во второй руке"), Some("Полоса истощения на фоне"), Some("Оценка восстановления здоровья"), Some("Анимация показателей подобно Minecraft"), Some("Максимальная видимость показателей"), Some("Показатели еды на экране отладки"), Some("Различные улучшения в интерфейсе еды.")]),
        ("tr_tr", [Some("AppleSkin"), Some("Açıklamada yemek değerini göster"), Some("Açıklamada her zaman yemek değerini göster"), Some("Doygunluğu göster"), Some("Tutulan yemekten kazanılacak açlığı göster"), Some("Diğer eldeki yemekten kazanılacak açlığı göster"), Some("Yorulmayı göster"), Some("Tahmin edilen canı göster"), Some("HUD ikonlarını Minecraftla eşleşmesi için animasyonla"), Some("Yanıp sönen HUD simgelerinin maksimum alfası"), Some("Hata ayıklama ekranında yemek değerlerini göster"), Some("Adds various food-related HUD improvements")]),
        ("uk_ua", [Some("AppleSkin"), Some("Показувати значення їжі у підказці"), Some("Завжди показувати значення їжі у підказці"), Some("Показувати насичення"), Some("Показувати відновлену ситність при утримуванні їжі"), Some("Показувати при утримуванні їжі у іншій руці"), Some("Показувати виснаження"), Some("Показувати приблизне відновлення здоров'я"), Some("Анімувати іконки згідно зі стандартними іконками Minecraft"), Some("Максимальна непрозорість миготіння іконок"), Some("Показувати значення їжі на екрані налагодження"), Some("Додає різноманітні покращення інтерфейсу, пов'язані з їжею")]),
        ("vi_vn", [Some("AppleSkin"), Some("Hiển thị giá trị thức ăn trong chú thích (tooltip)"), Some("Luôn luôn Hiển thị giá trị thức ăn trong chú thích (tooltip)"), Some("Hiển thị độ bão hòa ở lớp phủ"), Some("Hiện độ no được khôi phục từ đồ ăn đang được cầm"), Some("Hiển thị lớp phủ cho đồ ăn ở tay phụ"), Some("Hiển thị lớp lót kiệt sức"), Some("Hiển thị lớp phủ thanh máu"), Some("Tạo hoạt ảnh cho biểu tượng HUD để khớp với Minecraft"), Some("Alpha tối đa cho biểu tượng HUD nhấp nháy"), Some("Hiển thị giá trị thức ăn trong màn hình gỡ lỗi"), Some("Thêm các HUD được cải thiện liên qua đến đồ ăn")]),
        ("zh_cn", [Some("苹果皮 AppleSkin"), Some("显示食物的饥饿值和饱和度"), Some("始终显示食物的饥饿值和饱和度"), Some("显示饱和度"), Some("显示食用后预计恢复的饥饿值"), Some("显示副手食物信息"), Some("显示消耗度"), Some("显示食用后预计恢复的生命值"), Some("启用匹配原版HUD图标的动画"), Some("设置HUD闪烁图标的透明度"), Some("在调试屏幕中显示饥饿信息"), Some("增加了各种与食物相关的HUD改进")]),
        ("zh_tw", [Some("AppleSkin"), Some("在物品提示中顯示食物飽食度"), Some("總是在物品提示中顯示食物飽食度"), Some("顯示飽食度消耗重疊"), Some("手持食物時顯示可回復的飢餓值"), Some("食物在副手時顯示飢餓值重疊"), Some("顯示飽食度消耗值"), Some("顯示估計恢復的生命值覆蓋層"), Some("顯示動畫 HUD 圖示來與 Minecraft 相符"), Some("最大 HUD 圖示閃爍的不透明度"), Some("在除錯介面中顯示食物數值"), Some("新增多種食物顯示相關的 HUD 改進")]),
    ];
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn colours_floor_like_java() {
        assert_eq!(argb_from_rgba(1.0, 1.0, 1.0, 0.75), 0xBFFF_FFFF);
        assert_eq!(argb_from_rgba(1.0, 1.0, 1.0, 0.25), 0x3FFF_FFFF);
        assert_eq!(FoodOutline::Extra.argb(), 0xFF0F_5105);
        assert_eq!(FoodOutline::Missing.argb(), 0x7F9E_0000);
    }

    #[test]
    fn java_random_matches_known_sequence() {
        // new java.util.Random(42).nextInt(10) x5 = 0, 3, 8, 4, 0
        let mut r = JavaRandom::new(42);
        let got: Vec<i32> = (0..5).map(|_| r.next_int(10)).collect();
        assert_eq!(got, vec![0, 3, 8, 4, 0]);
        // nextInt(2) is a power of two: new Random(0).nextInt(2) = 1
        assert_eq!(JavaRandom::new(0).next_int(2), 1);
    }

    #[test]
    fn regen_estimate_matches_slow_and_fast_paths() {
        assert_eq!(estimated_regen(17, 0.0, 0.0), 0.0);
        // 18 food, no saturation: each heal costs 6 exhaustion, one food per 4.
        assert!(estimated_regen(18, 0.0, 0.0) > 0.0);
        assert_eq!(estimated_regen(20, f32::NAN, 0.0), 0.0);
        // A tiny saturation can't loop forever.
        let h = estimated_regen(20, 1e-40, 0.0);
        assert!(h.is_finite());
    }

    #[test]
    fn regeneration_effect_heals_by_its_interval() {
        let p = PlayerFood {
            health: 10.0, max_health: 20.0, absorption: 0.0, food: 10, saturation: 0.0, exhaustion: 0.0,
            natural_regeneration: true, peaceful: false, hardcore: false, poison: false, wither: false, regeneration: false,
        };
        let food = FoodProperties { nutrition: 4, saturation: 9.6, can_always_eat: true };
        let c = Consumable { apply_effects: vec![vec![StatusEffect { id: "regeneration".into(), amplifier: 1, duration: 100, harmful: false }]] };
        // golden apple: Regeneration II for 100 ticks heals every 25 ticks.
        assert_eq!(estimated_health_increment(&p, &food, &c), 4.0);
    }

    #[test]
    fn saturation_icons_pick_their_frame() {
        let offsets: Vec<(i32, i32)> = (0..10).map(|i| (-(i * 8) - 9, 0)).collect();
        let mut out = Vec::new();
        draw_saturation_overlay(&mut out, &offsets, 0.0, 5.0, 100, 50, 1.0);
        let us: Vec<i32> = out.iter().map(|d| match d { Draw::Icons { u, .. } => *u, _ => -1 }).collect();
        assert_eq!(us, vec![27, 27, 9]);
    }

    #[test]
    fn exhaustion_bar_grows_from_the_right() {
        let mut out = Vec::new();
        draw_exhaustion_overlay(&mut out, 2.0, 100, 50);
        assert_eq!(out, vec![Draw::Icons { x: 60, y: 50, u: 41, v: 18, w: 40, h: 9, color: 0xBFFF_FFFF }]);
    }

    #[test]
    fn tooltip_overlay_counts_bars_and_texts() {
        let food = FoodProperties { nutrition: 8, saturation: 12.8, can_always_eat: false };
        let r = QueriedFoodResult { default_food: food, modified_food: food, consumable: Consumable::default() };
        let o = FoodOverlay::new(&r);
        assert_eq!((o.hunger_bars, o.saturation_bars), (4, 7));
        assert_eq!(o.width(|_| 0), 49);
        let zero = FoodProperties { nutrition: 2, saturation: 0.0, can_always_eat: false };
        let o = FoodOverlay::new(&QueriedFoodResult { default_food: zero, modified_food: zero, consumable: Consumable::default() });
        assert_eq!(o.saturation_bars_text.as_deref(), Some("x0"));
        assert_eq!(FoodOutline::get(4, 4, 0), FoodOutline::Normal);
        assert_eq!(FoodOutline::get(3, 4, 2), FoodOutline::Partial);
    }

    #[test]
    fn config_round_trips_and_reads_jankson() {
        let mut c = ModConfig::default();
        c.show_saturation_hud_overlay = false;
        c.max_hud_overlay_flash_alpha = 0.4;
        assert_eq!(ModConfig::from_json5(&c.to_json5()), c);
        let jankson = "{\n\t/* comment, with: colon */\n\t\"showFoodValuesInTooltip\": false,\n\tmaxHudOverlayFlashAlpha: 0.3,\n}";
        let r = ModConfig::from_json5(jankson);
        assert!(!r.show_food_values_in_tooltip);
        assert_eq!(r.max_hud_overlay_flash_alpha, 0.3);
        let mut a = ModConfig::default();
        a.max_hud_overlay_flash_alpha = 1.0;
        a.click(8);
        assert_eq!(a.max_hud_overlay_flash_alpha, 0.0);
        a.click(8);
        assert_eq!(a.max_hud_overlay_flash_alpha, 0.05);
    }

    #[test]
    fn decimal_format_matches_java() {
        assert_eq!(decimal_format(5.0, 0, 2), "5");
        assert_eq!(decimal_format(4.0, 0, 2), "4");
        assert_eq!(decimal_format(0.0, 2, 2), "0.00");
        assert_eq!(decimal_format(1.6, 0, 2), "1.6");
        assert_eq!(decimal_format(0.125, 2, 2), "0.12");
        assert_eq!(decimal_format(0.375, 2, 2), "0.38");
        assert_eq!(decimal_format(3.999, 2, 2), "4.00");
        assert_eq!(debug_line(20, 5.0, 0.5), "hunger: 20, sat: 5, exh: 0.50/4");
    }

    #[test]
    fn payloads_are_big_endian_like_friendly_byte_buf() {
        assert_eq!(encode_float(1.0), [0x3F, 0x80, 0, 0]);
        assert_eq!(decode_sync(CHANNEL_SATURATION, &[0x40, 0xA0, 0, 0]), Some(Synced::Saturation(5.0)));
        assert_eq!(decode_sync(CHANNEL_NATURAL_REGENERATION, &[0]), Some(Synced::NaturalRegeneration(false)));
        let mut s = ServerSync::default();
        assert_eq!(s.on_player_update(1, 5.0, 0.0).len(), 2);
        assert!(s.on_player_update(1, 5.0, 0.005).is_empty());
        assert_eq!(s.on_player_update(1, 5.0, 0.02).len(), 1);
        assert!(s.on_level_tick(true).is_none());
        assert!(s.on_level_tick(false).is_some());
        assert_eq!(s.on_player_logged_in(2).len(), 1);
    }

    #[test]
    fn query_reads_components() {
        let mut c = std::collections::BTreeMap::new();
        c.insert("minecraft:food".to_owned(), serde_json::json!({"nutrition": 2, "saturation": 0.4}));
        c.insert("minecraft:consumable".to_owned(), serde_json::json!({"on_consume_effects": [
            {"type": "minecraft:apply_effects", "effects": [{"id": "minecraft:hunger", "duration": 600}], "probability": 0.8}
        ]}));
        let r = query(&c, |id| id.ends_with("hunger")).unwrap();
        assert_eq!(r.modified_food.nutrition, 2);
        assert!(is_rotten(&r.consumable));
        c.remove("minecraft:consumable");
        assert!(query(&c, |_| false).is_none());
    }

    #[test]
    fn embedded_textures_and_lang() {
        assert_eq!(icons_texel(0, 0), 0);
        assert_ne!(icons_texel(12, 0), 0);
        assert_eq!(outline_texel(-1, 0), 0);
        assert_eq!(title("de_de"), "AppleSkin");
        assert_eq!(option_label("xx_xx", 2), "Show saturation overlay");
        assert!(!summary("en_us").is_empty());
        let rects = texel_rects(icons_texel, 0, 0, 0, 18, 81, 9, 0xFFFF_FFFF);
        assert!(!rects.is_empty());
    }

    #[test]
    fn held_food_prefers_main_hand_then_off_hand() {
        let food = FoodProperties { nutrition: 4, saturation: 2.4, can_always_eat: false };
        let r = QueriedFoodResult { default_food: food, modified_food: food, consumable: Consumable::default() };
        let mut hud = Hud::default();
        let c = ModConfig::default();
        let got = hud.held_food(1, &c, || Hands { main: Some((r.clone(), false)), off: Some((r.clone(), true)) });
        assert!(got.is_some());
        // cached for the same GUI tick
        assert!(hud.held_food(1, &c, || Hands::default()).is_some());
        assert!(hud.held_food(2, &c, || Hands::default()).is_none());
    }
}
