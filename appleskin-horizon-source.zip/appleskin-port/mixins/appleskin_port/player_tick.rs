// ServerPlayerMixin: each player's saturation and exhaustion, sent when they change.
fn appleskin_port_player_tick(game: &mut crate::game::Game<'_>) {
    game.appleskin_player_tick();
}
