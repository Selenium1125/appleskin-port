// ClientSyncHandler: a server's appleskin:exhaustion, appleskin:saturation and
// appleskin:natural_regeneration payloads.
fn appleskin_port_client_packet(
    game: &mut crate::game::Game<'_>,
    packet: &horizon_client::mod_api::ClientboundPlayPacket,
) {
    if let horizon_client::mod_api::ClientboundPlayPacket::CustomPayload(p) = packet {
        game.appleskin_client_packet(&p.channel, &p.data);
    }
}
