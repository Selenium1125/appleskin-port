// HudMixin: AppleSkin's overlays around the health and food rows.
fn appleskin_port_health_hud(
    game: &mut crate::game::Game<'_>,
    inputs: &horizon_client::hud_layout::HealthInputs,
    wi: i32,
    hi: i32,
    draws: &mut Option<Vec<horizon_client::hud_layout::GuiDraw>>,
) {
    game.appleskin_health_hud(inputs, wi, hi, draws);
}
