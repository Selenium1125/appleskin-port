// MinecraftMixin: the flashing icons' alpha steps at the head of each client tick.
fn appleskin_port_client_tick(game: &mut crate::game::Game<'_>) {
    game.appleskin_client_tick();
}
