// The mod's row in Options > Mods.
fn appleskin_port_listed(mods: &mut Vec<crate::game::native_hooks::NativeMod>) {
    use crate::game::appleskin_port as m;
    let lang = horizon_client::lang::code();
    mods.push(crate::game::native_hooks::NativeMod {
        id: m::ID.into(),
        title: format!("{} {}", m::title(&lang), m::VERSION),
        description: m::summary(&lang).into(),
        keys: Vec::new(),
    });
}
