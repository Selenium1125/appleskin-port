# AppleSkin for Horizon

A 1:1 port of [AppleSkin](https://github.com/squeek502/AppleSkin) by **squeek502** to
[Horizon](https://github.com/horizon-rust/horizon) (Minecraft: Java Edition 26.3 rewritten in Rust), as a
native mod. Ported from AppleSkin 3.0.10 (`26.3-fabric`) with the author's permission. AppleSkin is
released under the Unlicense; so is this port (see [LICENSE](LICENSE)).

All credit for AppleSkin's design, textures and translations goes to squeek502 and its contributors.

## What it does

Everything AppleSkin 3.0.10 does on Java:

- **Saturation overlay**: your saturation drawn over the hunger bar, with AppleSkin's own icons.
- **Exhaustion underlay**: a bar behind the hunger bar showing how close you are to losing the next point.
- **Held food preview**: the hunger and saturation the food in your hand (or off hand) would restore, flashing on
  the bar; rotten food uses the hunger-effect icons.
- **Estimated health**: the health that food would restore through natural regeneration and Regeneration effects,
  flashing on the health bar.
- **Food values in tooltips**: hunger and saturation icons under a food's tooltip (always, or while holding Shift).
- **Vanilla shake**: the overlays shake with the hunger and health icons, using the same random sequence as the HUD.
- **Debug screen**: `hunger: 20, sat: 5, exh: 0.50/4` in F3.
- **Server sync**: a server running it sends each player's saturation, exhaustion and the
  `natural_health_regeneration` rule on AppleSkin's own channels (`appleskin:saturation`, `appleskin:exhaustion`,
  `appleskin:natural_regeneration`), and a client reads them. A Horizon client gets accurate values from a Java
  server running AppleSkin, and a Java client running AppleSkin gets them from a Horizon server running this mod.
- **Config**: `config/appleskin.json5`, the same file and keys as on Java, and a settings page in
  **Options > Mods > AppleSkin** with AppleSkin's own labels in all 22 of its languages.

## How it maps onto the original

| AppleSkin (Java) | This port |
| --- | --- |
| `HudMixin` (`extractFood` HEAD/RETURN, `extractHearts` RETURN) | `health_hud` hook: Horizon's own layout of the rows, with AppleSkin's draws inserted at the same three points |
| `MinecraftMixin` (`tick` HEAD) | `native_client_tick_pre` |
| `ItemStackMixin`, `ClientTooltipComponentMixin` | `tooltip_component` / `tooltip_component_draw` hooks, laid out so the box is vanilla's size |
| `FoodDataMixin` (exhaustion accessor) | reads `FoodData.exhaustion` directly |
| `ServerPlayerMixin`, `PlayerListMixin`, `SyncHandler` | `native_player_tick_pre`, `player_logged_in`, `level_tick_post`, sent with `native_send_custom_payload_to_player` |
| `ClientSyncHandler` | `client_packet` hook |
| `DebugInfoHudEntry` | injected into Horizon's F3 lines (`debug_entry_lines`) |
| `ModConfig` (Jankson), Mod Menu / Cloth Config screen | same `appleskin.json5`; Options > Mods page |
| `textures/icons.png`, `tooltip_hunger_outline` | drawn from the atlas when present, otherwise from AppleSkin's own texels embedded in the mod |

`runtime.rs` is AppleSkin's logic with nothing of Horizon in it, translated function by function (`FoodHelper`,
`HUDOverlayHandler`, `TooltipOverlayHandler`, `ColorHelper`, `ModConfig`, the payloads). `glue.rs` is the game side.

Differences you might notice:

- **No Java API.** AppleSkin's events (`FoodValuesEvent`, `HUDOverlayEvent`, `TooltipOverlayEvent`) exist for other
  Java mods, which can't run on Horizon.
- **Debug line switch.** On Java 26.3 the F3 line is a debug screen entry you enable with F3 + F6. Horizon's debug
  options list only has vanilla's entries, so the line is controlled by "Show food values in Debug Screen" on the
  settings page instead (AppleSkin's own option, still in its lang files), and shows while F3 is open.
- **Settings page.** Horizon's mod pages have buttons, not sliders, so "Max alpha of flashing HUD icons" steps by 0.05
  per click (wrapping from 1.00 to 0.00). Option descriptions are in the config file's comments.

## Checks

- `cargo test`: unit tests of the ported logic.
- `tools/difftest/run.sh`: runs AppleSkin's own code (copied into `Diff.java`) and the port on the same inputs and
  compares them: the health regeneration estimate, the icon shake (`java.util.Random`), and the debug line's
  `DecimalFormat`. They match on every line.
- The bundle applies with horizon-mixins on the pinned Nightly and type-checks with the game
  (`cargo check -p horizon-client`).

## Build and package

The bundle is pinned to Horizon Nightly 2026-11-08 (`fdc87ae`) and horizon-mixins `5a64af9`, the revision the
launcher uses. `python3 tools/package.py` writes `target/appleskin_port-3.0.10.hnmod`, the file Horizon's registry
and launcher take; the launcher compiles it into the game.
