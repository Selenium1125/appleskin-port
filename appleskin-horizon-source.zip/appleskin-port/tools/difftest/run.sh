#!/bin/sh
# Runs AppleSkin's own maths (Diff.java, copied from its source) and the port's, and compares
# them line by line: the health regeneration estimate, the icons' shake and the debug line's
# number formats.
set -e
cd "$(dirname "$0")"
javac -d . Diff.java
java -cp . Diff > java.txt
cargo run -q --manifest-path ../../Cargo.toml --example diff > rust.txt
diff java.txt rust.txt && echo "identical: $(wc -l < java.txt) lines"
