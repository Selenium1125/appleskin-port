import java.text.DecimalFormat;
import java.util.Random;
public class Diff {
	// Verbatim from AppleSkin 26.3-fabric FoodHelper
	public static float REGEN_EXHAUSTION_INCREMENT = 6.0F;
	public static float MAX_EXHAUSTION = 4.0F;
	public static float getEstimatedHealthIncrement(int foodLevel, float saturationLevel, float exhaustionLevel) {
		float health = 0;
		if (!Float.isFinite(exhaustionLevel) || !Float.isFinite(saturationLevel)) return 0;
		while (foodLevel >= 18) {
			while (exhaustionLevel > MAX_EXHAUSTION) {
				exhaustionLevel -= MAX_EXHAUSTION;
				if (saturationLevel > 0) saturationLevel = Math.max(saturationLevel - 1, 0); else foodLevel -= 1;
			}
			if (foodLevel >= 20 && Float.compare(saturationLevel, Float.MIN_NORMAL) > 0) {
				float limitedSaturationLevel = Math.min(saturationLevel, REGEN_EXHAUSTION_INCREMENT);
				float exhaustionUntilAboveMax = Math.nextUp(MAX_EXHAUSTION) - exhaustionLevel;
				int numIterationsUntilAboveMax = Math.max(1, (int) Math.ceil(exhaustionUntilAboveMax / limitedSaturationLevel));
				health += (limitedSaturationLevel / REGEN_EXHAUSTION_INCREMENT) * numIterationsUntilAboveMax;
				exhaustionLevel += limitedSaturationLevel * numIterationsUntilAboveMax;
			} else if (foodLevel >= 18) {
				health += 1; exhaustionLevel += REGEN_EXHAUSTION_INCREMENT;
			}
		}
		return health;
	}
	// OffsetsCache.generate, verbatim maths
	static String offsets(int guiTicks, float maxHealth, float absorption, float healthNow, int foodLevel, float saturationLevel) {
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		final int preferHealthBars = 10, preferFoodBars = 10;
		final float absorptionHealth = (float) Math.ceil(absorption);
		int healthBars = (int) Math.ceil((maxHealth + absorptionHealth) / 2.0F);
		if (healthBars < 0 || healthBars > 1000) healthBars = 0;
		int healthRows = (int) Math.ceil((float) healthBars / (float) preferHealthBars);
		int healthRowHeight = Math.max(10 - (healthRows - 2), 3);
		boolean shouldAnimatedFood = saturationLevel <= 0.0F && guiTicks % (foodLevel * 3 + 1) == 0;
		boolean shouldAnimatedHealth = Math.ceil(healthNow) <= 4;
		random.setSeed((long) (guiTicks * 312871));
		int[][] h = new int[healthBars][];
		for (int i = healthBars - 1; i >= 0; --i) {
			int row = (int) Math.ceil((float) (i + 1) / (float) preferHealthBars) - 1;
			int x = i % preferHealthBars * 8; int y = -(row * healthRowHeight);
			if (shouldAnimatedHealth) y += random.nextInt(2);
			h[i] = new int[]{x, y};
		}
		for (int[] p : h) sb.append(p[0]).append(',').append(p[1]).append(' ');
		sb.append('|');
		for (int i = 0; i < preferFoodBars; ++i) {
			int x = -(i * 8) - 9; int y = 0;
			if (shouldAnimatedFood) y += random.nextInt(3) - 1;
			sb.append(x).append(',').append(y).append(' ');
		}
		return sb.toString();
	}
	public static void main(String[] a) {
		DecimalFormat sat = new DecimalFormat("#.##"), ev = new DecimalFormat("0.00");
		for (int f = 16; f <= 20; f++)
			for (int s = 0; s <= 80; s += 3)
				for (int e = 0; e <= 50; e += 7) {
					float sl = s / 4.0f + 0.013f * e, el = e / 10.0f + 0.07f * s;
					System.out.println("regen " + f + " " + Float.floatToIntBits(sl) + " " + Float.floatToIntBits(el) + " " + Float.floatToIntBits(getEstimatedHealthIncrement(f, sl, el)));
				}
		for (int t = 0; t < 400; t += 13)
			for (float mh : new float[]{20f, 6f, 40f, 1f})
				for (float ab : new float[]{0f, 4f, 2.5f})
					for (float hn : new float[]{3f, 4.5f, 20f})
						System.out.println("off " + t + " " + mh + " " + ab + " " + hn + " " + (t % 7) + " " + (t % 3 == 0 ? 0f : 1.5f) + " " + offsets(t, mh, ab, hn, t % 7, t % 3 == 0 ? 0f : 1.5f));
		for (int i = 0; i < 4000; i++) {
			float v = i * 0.0025f;
			System.out.println("fmt " + Float.floatToIntBits(v) + " " + sat.format(v) + " " + ev.format(v));
		}
	}
}
