// Prints what difftest/Diff.java prints, from the port.
use horizon_mod_appleskin_port::*;
fn main() {
    for f in 16..=20 {
        for s in (0..=80).step_by(3) {
            for e in (0..=50).step_by(7) {
                let sl = s as f32 / 4.0 + 0.013f32 * e as f32;
                let el = e as f32 / 10.0 + 0.07f32 * s as f32;
                println!("regen {} {} {} {}", f, sl.to_bits() as i32, el.to_bits() as i32, estimated_regen(f, sl, el).to_bits() as i32);
            }
        }
    }
    let mut t = 0;
    while t < 400 {
        for mh in [20f32, 6.0, 40.0, 1.0] {
            for ab in [0f32, 4.0, 2.5] {
                for hn in [3f32, 4.5, 20.0] {
                    let food = t % 7;
                    let sat = if t % 3 == 0 { 0f32 } else { 1.5 };
                    let p = PlayerFood { health: hn, max_health: mh, absorption: ab, food, saturation: sat, exhaustion: 0.0,
                        natural_regeneration: true, peaceful: false, hardcore: false, poison: false, wither: false, regeneration: false };
                    let mut c = OffsetsCache::default();
                    c.generate(t, &p, true);
                    let mut line = String::new();
                    for (x, y) in &c.health { line.push_str(&format!("{x},{y} ")); }
                    line.push('|');
                    for (x, y) in &c.food { line.push_str(&format!("{x},{y} ")); }
                    println!("off {t} {mh:?} {ab:?} {hn:?} {food} {sat:?} {line}");
                }
            }
        }
        t += 13;
    }
    for i in 0..4000 {
        let v = i as f32 * 0.0025f32;
        println!("fmt {} {} {}", v.to_bits() as i32, decimal_format(v, 0, 2), decimal_format(v, 2, 2));
    }
}
