// Writes the port's draws for a sample HUD and tooltip as rectangles (x y w h argb) for a preview
// image: AppleSkin's own icons from the embedded texels, vanilla sprites as labelled boxes.
use horizon_mod_appleskin_port::*;
fn emit(draws: &[Draw]) {
    for d in draws {
        match d {
            Draw::Icons { x, y, u, v, w, h, color } => {
                for (x, y, w, h, c) in texel_rects(icons_texel, *x, *y, *u, *v, *w, *h, *color) {
                    println!("R {x} {y} {w} {h} {c}");
                }
            }
            Draw::Outline { x, y, color } => {
                for (x, y, w, h, c) in texel_rects(outline_texel, *x, *y, 0, 0, 9, 9, *color) {
                    println!("R {x} {y} {w} {h} {c}");
                }
            }
            Draw::Sprite { sprite, x, y, w, h, color } => println!("S {x} {y} {w} {h} {color} {sprite}"),
            _ => {}
        }
    }
}
fn main() {
    let config = ModConfig::default();
    let p = PlayerFood { health: 13.0, max_health: 20.0, absorption: 0.0, food: 12, saturation: 7.5, exhaustion: 2.5,
        natural_regeneration: true, peaceful: false, hardcore: false, poison: false, wither: false, regeneration: false };
    let bread = FoodProperties { nutrition: 5, saturation: 6.0, can_always_eat: false };
    let held = QueriedFoodResult { default_food: bread, modified_food: bread, consumable: Consumable::default() };
    let mut hud = Hud::default();
    for _ in 0..6 { hud.on_client_tick(&config); }
    let (left, right, top) = (20, 202, 40);
    let hands = || Hands { main: Some((held.clone(), true)), off: None };
    let mut all = hud.render_health(&config, &p, left, top, 5, hands);
    all.extend(hud.pre_render_food(&config, &p, top, right));
    all.extend(hud.render_food(&config, &p, top, right, 5, hands));
    emit(&all);
    let steak = FoodProperties { nutrition: 8, saturation: 12.8, can_always_eat: false };
    let o = FoodOverlay::new(&QueriedFoodResult { default_food: steak, modified_food: steak, consumable: Consumable::default() });
    emit(&o.render(30, 70));
}
